﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using System.Xml.Linq;

namespace HostelManagement
{
    public partial class UpdateDeleteEmployee : Form
    {
        function fn = new function();
        String query;


        public UpdateDeleteEmployee()
        {
            InitializeComponent();
        }

        private void UpdateDeleteEmployee_Load(object sender, EventArgs e)
        {
            this.Location = new Point(350, 170);
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            query = "select * from newEmployee where emobile =" + txtMobno.Text + "";
            DataSet ds = fn.getData(query);
            if (ds.Tables[0].Rows.Count != 0)
            {
                txtName.Text = ds.Tables[0].Rows[0][2].ToString();
                txtFname.Text = ds.Tables[0].Rows[0][3].ToString();
                txtMname.Text = ds.Tables[0].Rows[0][4].ToString();
                txtEmail.Text = ds.Tables[0].Rows[0][5].ToString();
                txtAddr.Text = ds.Tables[0].Rows[0][6].ToString();
                txtUid.Text = ds.Tables[0].Rows[0][7].ToString();
                txtDesignation.Text = ds.Tables[0].Rows[0][8].ToString();
                txtworking.Text = ds.Tables[0].Rows[0][9].ToString();
            }
            else
            {
                MessageBox.Show("No Record Exist.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                clearAll();
            }

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            //String mob = txtMobno.Text;
            Int64 mobile = Int64.Parse(txtMobno.Text);
            String name = txtName.Text;
            String fname = txtFname.Text;
            String mname = txtMname.Text;
            String email = txtEmail.Text;
            String addr = txtAddr.Text;
            String uid = txtUid.Text;
            String designation = txtDesignation.Text;
            String working = txtworking.Text;


            query = "update newEmployee set ename='" + name + "', efname='" + fname + "',emname='" + mname + "',eemail='" + email + "'," +
                "epaddress='" + addr + "',eidproof='" + uid + "',edesignation='" + designation + "',working='" + working + "'" +
                "where emobile='" + mobile + "' ";
/*            query = "update newEmployee set emobile='" + mobile + "',ename='" + name + "', efname='" + fname + "',emname='" + mname + "',eemail='" + email + "'," +
                "epaddress='" + addr + "',eidproof='" + uid + "',edesignation='" + designation + "',working='" + working + "'" +
                "where emobile='" + mobile + "' "; */
            fn.setData(query, "Data Updation Succesfully...");
            clearAll();

            //"update newEmployee set ename='" + name + "', efname='" + fname + "',epaddress='" + addr + "',eidproof='" + uid + "',edesignation='" + designation + "',working='" + working + "' where  where emobile=""+mobile+"";
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                query = "delete from newEmployee where emobile=" + txtMobno.Text + " ";
                fn.setData(query, "Employee Record Deleted Sucesfully.....");
                clearAll();
            }
        }
        public void clearAll()
        {
            txtMobno.Clear();
            txtName.Clear();
            txtFname.Clear();
            txtMname.Clear();
            txtEmail.Clear();
            txtAddr.Clear();
            txtUid.Clear();
            txtDesignation.SelectedIndex = -1;
            txtworking.SelectedIndex = -1;
        }

        private void txtClr_Click(object sender, EventArgs e)
        {
            clearAll();
        }
    }
}
