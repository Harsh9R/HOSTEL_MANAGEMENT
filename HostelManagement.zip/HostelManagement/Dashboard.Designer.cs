﻿namespace HostelManagement
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dashboard));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges21 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges22 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges23 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges24 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges25 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges26 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges27 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges28 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            hmsLabel = new Label();
            btnManageRooms = new Guna.UI2.WinForms.Guna2Button();
            btnAllEmployeeWorking = new Guna.UI2.WinForms.Guna2Button();
            guna2Button5 = new Guna.UI2.WinForms.Guna2Button();
            guna2Button6 = new Guna.UI2.WinForms.Guna2Button();
            btnNewEmployee = new Guna.UI2.WinForms.Guna2Button();
            btnLeavedStudents = new Guna.UI2.WinForms.Guna2Button();
            btnAllStudentLiving = new Guna.UI2.WinForms.Guna2Button();
            guna2Button10 = new Guna.UI2.WinForms.Guna2Button();
            btnUpdateDeleteStudent = new Guna.UI2.WinForms.Guna2Button();
            btnNewStudent = new Guna.UI2.WinForms.Guna2Button();
            btnLeavedEmployee = new Guna.UI2.WinForms.Guna2Button();
            btnLogOut = new Guna.UI2.WinForms.Guna2Button();
            timer1 = new System.Windows.Forms.Timer(components);
            guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            btnExit = new Guna.UI2.WinForms.Guna2Button();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox1).BeginInit();
            SuspendLayout();
            // 
            // hmsLabel
            // 
            hmsLabel.AutoSize = true;
            hmsLabel.Font = new Font("Microsoft Sans Serif", 28.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            hmsLabel.ForeColor = Color.Black;
            hmsLabel.Location = new Point(483, 20);
            hmsLabel.Margin = new Padding(2, 0, 2, 0);
            hmsLabel.Name = "hmsLabel";
            hmsLabel.Size = new Size(634, 54);
            hmsLabel.TabIndex = 2;
            hmsLabel.Text = "Hostel Management System";
            hmsLabel.Click += hmsLabel_Click;
            // 
            // btnManageRooms
            // 
            btnManageRooms.BackColor = Color.FromArgb(255, 128, 0);
            btnManageRooms.BorderRadius = 19;
            btnManageRooms.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            btnManageRooms.CustomizableEdges = customizableEdges1;
            btnManageRooms.DisabledState.BorderColor = Color.DarkGray;
            btnManageRooms.DisabledState.CustomBorderColor = Color.DarkGray;
            btnManageRooms.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnManageRooms.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnManageRooms.FillColor = Color.FromArgb(192, 255, 255);
            btnManageRooms.Font = new Font("Microsoft Sans Serif", 12F);
            btnManageRooms.ForeColor = Color.Black;
            btnManageRooms.Image = (Image)resources.GetObject("btnManageRooms.Image");
            btnManageRooms.ImageSize = new Size(35, 35);
            btnManageRooms.Location = new Point(11, 101);
            btnManageRooms.Margin = new Padding(2);
            btnManageRooms.Name = "btnManageRooms";
            btnManageRooms.ShadowDecoration.CustomizableEdges = customizableEdges2;
            btnManageRooms.Size = new Size(278, 54);
            btnManageRooms.TabIndex = 3;
            btnManageRooms.Text = "Manage Rooms";
            btnManageRooms.Click += btnManageRooms_Click;
            // 
            // btnAllEmployeeWorking
            // 
            btnAllEmployeeWorking.BackColor = Color.FromArgb(255, 128, 0);
            btnAllEmployeeWorking.BorderRadius = 19;
            btnAllEmployeeWorking.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            btnAllEmployeeWorking.CustomizableEdges = customizableEdges3;
            btnAllEmployeeWorking.DisabledState.BorderColor = Color.DarkGray;
            btnAllEmployeeWorking.DisabledState.CustomBorderColor = Color.DarkGray;
            btnAllEmployeeWorking.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnAllEmployeeWorking.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnAllEmployeeWorking.FillColor = Color.FromArgb(192, 255, 255);
            btnAllEmployeeWorking.Font = new Font("Microsoft Sans Serif", 12F);
            btnAllEmployeeWorking.ForeColor = Color.Black;
            btnAllEmployeeWorking.Image = (Image)resources.GetObject("btnAllEmployeeWorking.Image");
            btnAllEmployeeWorking.ImageSize = new Size(35, 35);
            btnAllEmployeeWorking.Location = new Point(11, 588);
            btnAllEmployeeWorking.Margin = new Padding(2);
            btnAllEmployeeWorking.Name = "btnAllEmployeeWorking";
            btnAllEmployeeWorking.ShadowDecoration.CustomizableEdges = customizableEdges4;
            btnAllEmployeeWorking.Size = new Size(278, 47);
            btnAllEmployeeWorking.TabIndex = 6;
            btnAllEmployeeWorking.Text = "All Employee Working";
            btnAllEmployeeWorking.Click += btnAllEmployeeWorking_Click;
            // 
            // guna2Button5
            // 
            guna2Button5.BackColor = Color.FromArgb(255, 128, 0);
            guna2Button5.BorderRadius = 19;
            guna2Button5.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            guna2Button5.CustomizableEdges = customizableEdges5;
            guna2Button5.DisabledState.BorderColor = Color.DarkGray;
            guna2Button5.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button5.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button5.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button5.FillColor = Color.FromArgb(192, 255, 255);
            guna2Button5.Font = new Font("Microsoft Sans Serif", 12F);
            guna2Button5.ForeColor = Color.Black;
            guna2Button5.Image = (Image)resources.GetObject("guna2Button5.Image");
            guna2Button5.ImageSize = new Size(35, 35);
            guna2Button5.Location = new Point(11, 536);
            guna2Button5.Margin = new Padding(2);
            guna2Button5.Name = "guna2Button5";
            guna2Button5.ShadowDecoration.CustomizableEdges = customizableEdges6;
            guna2Button5.Size = new Size(278, 48);
            guna2Button5.TabIndex = 7;
            guna2Button5.Text = "Employee Payment";
            guna2Button5.Click += guna2Button5_Click;
            // 
            // guna2Button6
            // 
            guna2Button6.BackColor = Color.FromArgb(255, 128, 0);
            guna2Button6.BorderRadius = 19;
            guna2Button6.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            guna2Button6.CustomizableEdges = customizableEdges7;
            guna2Button6.DisabledState.BorderColor = Color.DarkGray;
            guna2Button6.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button6.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button6.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button6.FillColor = Color.FromArgb(192, 255, 255);
            guna2Button6.Font = new Font("Microsoft Sans Serif", 12F);
            guna2Button6.ForeColor = Color.Black;
            guna2Button6.Image = (Image)resources.GetObject("guna2Button6.Image");
            guna2Button6.ImageSize = new Size(35, 35);
            guna2Button6.Location = new Point(11, 481);
            guna2Button6.Margin = new Padding(2);
            guna2Button6.Name = "guna2Button6";
            guna2Button6.ShadowDecoration.CustomizableEdges = customizableEdges8;
            guna2Button6.Size = new Size(278, 51);
            guna2Button6.TabIndex = 8;
            guna2Button6.Text = "Update & Delete Employee";
            guna2Button6.TextFormatNoPrefix = true;
            guna2Button6.Click += guna2Button6_Click;
            // 
            // btnNewEmployee
            // 
            btnNewEmployee.BackColor = Color.FromArgb(255, 128, 0);
            btnNewEmployee.BorderRadius = 19;
            btnNewEmployee.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            btnNewEmployee.CustomizableEdges = customizableEdges9;
            btnNewEmployee.DisabledState.BorderColor = Color.DarkGray;
            btnNewEmployee.DisabledState.CustomBorderColor = Color.DarkGray;
            btnNewEmployee.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnNewEmployee.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnNewEmployee.FillColor = Color.FromArgb(192, 255, 255);
            btnNewEmployee.Font = new Font("Microsoft Sans Serif", 12F);
            btnNewEmployee.ForeColor = Color.Black;
            btnNewEmployee.Image = (Image)resources.GetObject("btnNewEmployee.Image");
            btnNewEmployee.ImageSize = new Size(35, 35);
            btnNewEmployee.Location = new Point(11, 423);
            btnNewEmployee.Margin = new Padding(2);
            btnNewEmployee.Name = "btnNewEmployee";
            btnNewEmployee.ShadowDecoration.CustomizableEdges = customizableEdges10;
            btnNewEmployee.Size = new Size(278, 54);
            btnNewEmployee.TabIndex = 9;
            btnNewEmployee.Text = "New Employee";
            btnNewEmployee.Click += btnNewEmployee_Click;
            // 
            // btnLeavedStudents
            // 
            btnLeavedStudents.BackColor = Color.FromArgb(255, 128, 0);
            btnLeavedStudents.BorderRadius = 19;
            btnLeavedStudents.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            btnLeavedStudents.CustomizableEdges = customizableEdges11;
            btnLeavedStudents.DisabledState.BorderColor = Color.DarkGray;
            btnLeavedStudents.DisabledState.CustomBorderColor = Color.DarkGray;
            btnLeavedStudents.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnLeavedStudents.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnLeavedStudents.FillColor = Color.FromArgb(192, 255, 255);
            btnLeavedStudents.Font = new Font("Microsoft Sans Serif", 12F);
            btnLeavedStudents.ForeColor = Color.Black;
            btnLeavedStudents.Image = (Image)resources.GetObject("btnLeavedStudents.Image");
            btnLeavedStudents.ImageSize = new Size(35, 35);
            btnLeavedStudents.Location = new Point(11, 367);
            btnLeavedStudents.Margin = new Padding(2);
            btnLeavedStudents.Name = "btnLeavedStudents";
            btnLeavedStudents.ShadowDecoration.CustomizableEdges = customizableEdges12;
            btnLeavedStudents.Size = new Size(278, 52);
            btnLeavedStudents.TabIndex = 10;
            btnLeavedStudents.Text = "Leaved Student";
            btnLeavedStudents.Click += btnLeavedStudents_Click;
            // 
            // btnAllStudentLiving
            // 
            btnAllStudentLiving.BackColor = Color.FromArgb(255, 128, 0);
            btnAllStudentLiving.BorderRadius = 19;
            btnAllStudentLiving.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            btnAllStudentLiving.CustomizableEdges = customizableEdges13;
            btnAllStudentLiving.DisabledState.BorderColor = Color.DarkGray;
            btnAllStudentLiving.DisabledState.CustomBorderColor = Color.DarkGray;
            btnAllStudentLiving.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnAllStudentLiving.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnAllStudentLiving.FillColor = Color.FromArgb(192, 255, 255);
            btnAllStudentLiving.Font = new Font("Microsoft Sans Serif", 12F);
            btnAllStudentLiving.ForeColor = Color.Black;
            btnAllStudentLiving.Image = (Image)resources.GetObject("btnAllStudentLiving.Image");
            btnAllStudentLiving.ImageSize = new Size(35, 35);
            btnAllStudentLiving.Location = new Point(11, 315);
            btnAllStudentLiving.Margin = new Padding(2);
            btnAllStudentLiving.Name = "btnAllStudentLiving";
            btnAllStudentLiving.ShadowDecoration.CustomizableEdges = customizableEdges14;
            btnAllStudentLiving.Size = new Size(278, 48);
            btnAllStudentLiving.TabIndex = 11;
            btnAllStudentLiving.Text = "All Student Living";
            btnAllStudentLiving.Click += btnAllStudentLiving_Click;
            // 
            // guna2Button10
            // 
            guna2Button10.BackColor = Color.FromArgb(255, 128, 0);
            guna2Button10.BorderRadius = 19;
            guna2Button10.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            guna2Button10.CustomizableEdges = customizableEdges15;
            guna2Button10.DisabledState.BorderColor = Color.DarkGray;
            guna2Button10.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button10.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button10.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button10.FillColor = Color.FromArgb(192, 255, 255);
            guna2Button10.Font = new Font("Microsoft Sans Serif", 12F);
            guna2Button10.ForeColor = Color.Black;
            guna2Button10.Image = (Image)resources.GetObject("guna2Button10.Image");
            guna2Button10.ImageSize = new Size(35, 35);
            guna2Button10.Location = new Point(11, 261);
            guna2Button10.Margin = new Padding(2);
            guna2Button10.Name = "guna2Button10";
            guna2Button10.ShadowDecoration.CustomizableEdges = customizableEdges16;
            guna2Button10.Size = new Size(278, 50);
            guna2Button10.TabIndex = 12;
            guna2Button10.Text = "Student Fees";
            guna2Button10.Click += guna2Button10_Click;
            // 
            // btnUpdateDeleteStudent
            // 
            btnUpdateDeleteStudent.BackColor = Color.FromArgb(255, 128, 0);
            btnUpdateDeleteStudent.BorderRadius = 19;
            btnUpdateDeleteStudent.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            btnUpdateDeleteStudent.CustomizableEdges = customizableEdges17;
            btnUpdateDeleteStudent.DisabledState.BorderColor = Color.DarkGray;
            btnUpdateDeleteStudent.DisabledState.CustomBorderColor = Color.DarkGray;
            btnUpdateDeleteStudent.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnUpdateDeleteStudent.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnUpdateDeleteStudent.FillColor = Color.FromArgb(192, 255, 255);
            btnUpdateDeleteStudent.Font = new Font("Microsoft Sans Serif", 12F);
            btnUpdateDeleteStudent.ForeColor = Color.Black;
            btnUpdateDeleteStudent.Image = (Image)resources.GetObject("btnUpdateDeleteStudent.Image");
            btnUpdateDeleteStudent.ImageSize = new Size(35, 35);
            btnUpdateDeleteStudent.Location = new Point(11, 209);
            btnUpdateDeleteStudent.Margin = new Padding(2);
            btnUpdateDeleteStudent.Name = "btnUpdateDeleteStudent";
            btnUpdateDeleteStudent.ShadowDecoration.CustomizableEdges = customizableEdges18;
            btnUpdateDeleteStudent.Size = new Size(278, 48);
            btnUpdateDeleteStudent.TabIndex = 13;
            btnUpdateDeleteStudent.Text = "Update & Delete Student";
            btnUpdateDeleteStudent.TextFormatNoPrefix = true;
            btnUpdateDeleteStudent.Click += btnUpdateDeleteStudent_Click;
            // 
            // btnNewStudent
            // 
            btnNewStudent.BackColor = Color.FromArgb(255, 128, 0);
            btnNewStudent.BorderRadius = 19;
            btnNewStudent.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            btnNewStudent.CustomizableEdges = customizableEdges19;
            btnNewStudent.DisabledState.BorderColor = Color.DarkGray;
            btnNewStudent.DisabledState.CustomBorderColor = Color.DarkGray;
            btnNewStudent.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnNewStudent.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnNewStudent.FillColor = Color.FromArgb(192, 255, 255);
            btnNewStudent.Font = new Font("Microsoft Sans Serif", 12F);
            btnNewStudent.ForeColor = Color.Black;
            btnNewStudent.Image = (Image)resources.GetObject("btnNewStudent.Image");
            btnNewStudent.ImageSize = new Size(35, 35);
            btnNewStudent.Location = new Point(11, 159);
            btnNewStudent.Margin = new Padding(2);
            btnNewStudent.Name = "btnNewStudent";
            btnNewStudent.ShadowDecoration.CustomizableEdges = customizableEdges20;
            btnNewStudent.Size = new Size(278, 46);
            btnNewStudent.TabIndex = 14;
            btnNewStudent.Text = "New Student";
            btnNewStudent.Click += btnNewStudent_Click;
            // 
            // btnLeavedEmployee
            // 
            btnLeavedEmployee.BackColor = Color.FromArgb(255, 128, 0);
            btnLeavedEmployee.BorderRadius = 19;
            btnLeavedEmployee.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            btnLeavedEmployee.CustomizableEdges = customizableEdges21;
            btnLeavedEmployee.DisabledState.BorderColor = Color.DarkGray;
            btnLeavedEmployee.DisabledState.CustomBorderColor = Color.DarkGray;
            btnLeavedEmployee.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnLeavedEmployee.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnLeavedEmployee.FillColor = Color.FromArgb(192, 255, 255);
            btnLeavedEmployee.Font = new Font("Microsoft Sans Serif", 12F);
            btnLeavedEmployee.ForeColor = Color.Black;
            btnLeavedEmployee.Image = (Image)resources.GetObject("btnLeavedEmployee.Image");
            btnLeavedEmployee.ImageSize = new Size(35, 35);
            btnLeavedEmployee.Location = new Point(11, 639);
            btnLeavedEmployee.Margin = new Padding(2);
            btnLeavedEmployee.Name = "btnLeavedEmployee";
            btnLeavedEmployee.ShadowDecoration.CustomizableEdges = customizableEdges22;
            btnLeavedEmployee.Size = new Size(278, 47);
            btnLeavedEmployee.TabIndex = 15;
            btnLeavedEmployee.Text = "Leaved Employee";
            btnLeavedEmployee.Click += btnLeavedEmployee_Click;
            // 
            // btnLogOut
            // 
            btnLogOut.BackColor = Color.FromArgb(255, 128, 0);
            btnLogOut.BorderColor = Color.DarkRed;
            btnLogOut.BorderRadius = 22;
            btnLogOut.BorderThickness = 5;
            btnLogOut.CustomizableEdges = customizableEdges23;
            btnLogOut.DisabledState.BorderColor = Color.DarkGray;
            btnLogOut.DisabledState.CustomBorderColor = Color.DarkGray;
            btnLogOut.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnLogOut.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnLogOut.FillColor = Color.FromArgb(255, 128, 0);
            btnLogOut.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnLogOut.ForeColor = Color.Black;
            btnLogOut.HoverState.BorderColor = Color.Black;
            btnLogOut.HoverState.FillColor = Color.White;
            btnLogOut.HoverState.ForeColor = Color.Black;
            btnLogOut.Image = (Image)resources.GetObject("btnLogOut.Image");
            btnLogOut.ImageSize = new Size(30, 30);
            btnLogOut.Location = new Point(1292, 11);
            btnLogOut.Margin = new Padding(2);
            btnLogOut.Name = "btnLogOut";
            btnLogOut.RightToLeft = RightToLeft.No;
            btnLogOut.ShadowDecoration.CustomizableEdges = customizableEdges24;
            btnLogOut.Size = new Size(137, 42);
            btnLogOut.TabIndex = 16;
            btnLogOut.Text = "Log Out";
            btnLogOut.Click += btnLogOut_Click;
            // 
            // timer1
            // 
            timer1.Enabled = true;
            timer1.Interval = 800;
            timer1.Tick += timer1_Tick;
            // 
            // guna2PictureBox1
            // 
            guna2PictureBox1.BorderRadius = 30;
            guna2PictureBox1.CustomizableEdges = customizableEdges25;
            guna2PictureBox1.Image = (Image)resources.GetObject("guna2PictureBox1.Image");
            guna2PictureBox1.ImageRotate = 0F;
            guna2PictureBox1.Location = new Point(328, 85);
            guna2PictureBox1.Margin = new Padding(2);
            guna2PictureBox1.Name = "guna2PictureBox1";
            guna2PictureBox1.ShadowDecoration.CustomizableEdges = customizableEdges26;
            guna2PictureBox1.Size = new Size(1067, 613);
            guna2PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            guna2PictureBox1.TabIndex = 0;
            guna2PictureBox1.TabStop = false;
            guna2PictureBox1.Click += guna2PictureBox1_Click_1;
            // 
            // btnExit
            // 
            btnExit.BorderRadius = 15;
            btnExit.CustomizableEdges = customizableEdges27;
            btnExit.DisabledState.BorderColor = Color.DarkGray;
            btnExit.DisabledState.CustomBorderColor = Color.DarkGray;
            btnExit.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnExit.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnExit.FillColor = Color.FromArgb(255, 128, 0);
            btnExit.Font = new Font("Segoe UI", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnExit.ForeColor = Color.White;
            btnExit.Image = (Image)resources.GetObject("btnExit.Image");
            btnExit.ImageSize = new Size(50, 50);
            btnExit.Location = new Point(1434, 4);
            btnExit.Margin = new Padding(3, 2, 3, 2);
            btnExit.Name = "btnExit";
            btnExit.RightToLeft = RightToLeft.No;
            btnExit.ShadowDecoration.CustomizableEdges = customizableEdges28;
            btnExit.Size = new Size(62, 58);
            btnExit.TabIndex = 60;
            btnExit.Click += btnExit_Click_1;
            // 
            // Dashboard
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 128, 0);
            ClientSize = new Size(1496, 772);
            Controls.Add(btnExit);
            Controls.Add(btnLogOut);
            Controls.Add(btnLeavedEmployee);
            Controls.Add(btnNewStudent);
            Controls.Add(btnUpdateDeleteStudent);
            Controls.Add(guna2Button10);
            Controls.Add(btnAllStudentLiving);
            Controls.Add(btnLeavedStudents);
            Controls.Add(btnNewEmployee);
            Controls.Add(guna2Button6);
            Controls.Add(guna2Button5);
            Controls.Add(btnAllEmployeeWorking);
            Controls.Add(btnManageRooms);
            Controls.Add(hmsLabel);
            Controls.Add(guna2PictureBox1);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(2);
            Name = "Dashboard";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Dashboard";
            Load += Dashboard_Load;
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label hmsLabel;
        private Guna.UI2.WinForms.Guna2Button btnManageRooms;
        private Guna.UI2.WinForms.Guna2Button btnAllEmployeeWorking;
        private Guna.UI2.WinForms.Guna2Button guna2Button5;
        private Guna.UI2.WinForms.Guna2Button guna2Button6;
        private Guna.UI2.WinForms.Guna2Button btnNewEmployee;
        private Guna.UI2.WinForms.Guna2Button btnLeavedStudents;
        private Guna.UI2.WinForms.Guna2Button btnAllStudentLiving;
        private Guna.UI2.WinForms.Guna2Button guna2Button10;
        private Guna.UI2.WinForms.Guna2Button btnUpdateDeleteStudent;
        private Guna.UI2.WinForms.Guna2Button btnNewStudent;
        private Guna.UI2.WinForms.Guna2Button btnLeavedEmployee;
        private Guna.UI2.WinForms.Guna2Button btnLogOut;
        private System.Windows.Forms.Timer timer1;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private Guna.UI2.WinForms.Guna2Button btnExit;
    }
}