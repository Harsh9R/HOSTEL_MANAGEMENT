﻿
namespace LoginRegistrationForm
{
    partial class Signup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Signup));
            panel1 = new Panel();
            label9 = new Label();
            signup_password = new TextBox();
            label8 = new Label();
            signup_close = new Label();
            signup_loginHere = new Label();
            label4 = new Label();
            signup_showPass = new CheckBox();
            signup_btn = new Button();
            signup_username = new TextBox();
            label3 = new Label();
            signup_email = new TextBox();
            label2 = new Label();
            label1 = new Label();
            panel2 = new Panel();
            pictureBox1 = new PictureBox();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.Controls.Add(label9);
            panel1.Controls.Add(signup_password);
            panel1.Controls.Add(label8);
            panel1.Controls.Add(signup_close);
            panel1.Controls.Add(signup_loginHere);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(signup_showPass);
            panel1.Controls.Add(signup_btn);
            panel1.Controls.Add(signup_username);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(signup_email);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(panel2);
            panel1.Location = new Point(-2, -2);
            panel1.Margin = new Padding(4, 6, 4, 6);
            panel1.Name = "panel1";
            panel1.Size = new Size(948, 704);
            panel1.TabIndex = 1;
            panel1.Paint += panel1_Paint;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label9.Location = new Point(324, 360);
            label9.Margin = new Padding(4, 0, 4, 0);
            label9.Name = "label9";
            label9.Size = new Size(104, 25);
            label9.TabIndex = 13;
            label9.Text = "Password:";
            // 
            // signup_password
            // 
            signup_password.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            signup_password.Location = new Point(328, 396);
            signup_password.Margin = new Padding(4, 6, 4, 6);
            signup_password.Multiline = true;
            signup_password.Name = "signup_password";
            signup_password.PasswordChar = '*';
            signup_password.Size = new Size(506, 54);
            signup_password.TabIndex = 12;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.Location = new Point(321, 364);
            label8.Margin = new Padding(4, 0, 4, 0);
            label8.Name = "label8";
            label8.Size = new Size(0, 25);
            label8.TabIndex = 11;
            // 
            // signup_close
            // 
            signup_close.AutoSize = true;
            signup_close.Cursor = Cursors.Hand;
            signup_close.Font = new Font("Microsoft Sans Serif", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            signup_close.Location = new Point(1016, 19);
            signup_close.Margin = new Padding(4, 0, 4, 0);
            signup_close.Name = "signup_close";
            signup_close.Size = new Size(30, 29);
            signup_close.TabIndex = 10;
            signup_close.Text = "X";
            signup_close.Click += signup_close_Click;
            // 
            // signup_loginHere
            // 
            signup_loginHere.AutoSize = true;
            signup_loginHere.Cursor = Cursors.Hand;
            signup_loginHere.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            signup_loginHere.ForeColor = Color.DimGray;
            signup_loginHere.Location = new Point(574, 616);
            signup_loginHere.Margin = new Padding(4, 0, 4, 0);
            signup_loginHere.Name = "signup_loginHere";
            signup_loginHere.Size = new Size(105, 22);
            signup_loginHere.TabIndex = 9;
            signup_loginHere.Text = "Login here";
            signup_loginHere.Click += signup_loginHere_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.DimGray;
            label4.Location = new Point(325, 616);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(218, 22);
            label4.TabIndex = 8;
            label4.Text = "Already have an account?";
            // 
            // signup_showPass
            // 
            signup_showPass.AutoSize = true;
            signup_showPass.BackColor = Color.Transparent;
            signup_showPass.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            signup_showPass.ForeColor = Color.Gray;
            signup_showPass.Location = new Point(630, 468);
            signup_showPass.Margin = new Padding(4, 6, 4, 6);
            signup_showPass.Name = "signup_showPass";
            signup_showPass.Size = new Size(179, 29);
            signup_showPass.TabIndex = 7;
            signup_showPass.Text = "Show Password";
            signup_showPass.UseVisualStyleBackColor = false;
            signup_showPass.CheckedChanged += signup_showPass_CheckedChanged;
            // 
            // signup_btn
            // 
            signup_btn.BackColor = Color.MidnightBlue;
            signup_btn.Cursor = Cursors.Hand;
            signup_btn.FlatAppearance.BorderSize = 0;
            signup_btn.FlatStyle = FlatStyle.Flat;
            signup_btn.ForeColor = Color.White;
            signup_btn.Location = new Point(327, 524);
            signup_btn.Margin = new Padding(4, 6, 4, 6);
            signup_btn.Name = "signup_btn";
            signup_btn.Size = new Size(167, 68);
            signup_btn.TabIndex = 6;
            signup_btn.Text = "SIGNUP";
            signup_btn.UseVisualStyleBackColor = false;
            signup_btn.Click += signup_btn_Click;
            // 
            // signup_username
            // 
            signup_username.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            signup_username.Location = new Point(327, 268);
            signup_username.Margin = new Padding(4, 6, 4, 6);
            signup_username.Multiline = true;
            signup_username.Name = "signup_username";
            signup_username.Size = new Size(506, 54);
            signup_username.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(321, 232);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(108, 25);
            label3.TabIndex = 4;
            label3.Text = "Username:";
            // 
            // signup_email
            // 
            signup_email.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            signup_email.Location = new Point(327, 150);
            signup_email.Margin = new Padding(4, 6, 4, 6);
            signup_email.Multiline = true;
            signup_email.Name = "signup_email";
            signup_email.Size = new Size(506, 54);
            signup_email.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(321, 114);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(144, 25);
            label2.TabIndex = 2;
            label2.Text = "Email Address:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("MS UI Gothic", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(320, 27);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(168, 29);
            label1.TabIndex = 1;
            label1.Text = "Get Started";
            // 
            // panel2
            // 
            panel2.BackColor = Color.MidnightBlue;
            panel2.Controls.Add(pictureBox1);
            panel2.Location = new Point(0, 0);
            panel2.Margin = new Padding(4, 6, 4, 6);
            panel2.Name = "panel2";
            panel2.Size = new Size(275, 704);
            panel2.TabIndex = 0;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.InitialImage = (Image)resources.GetObject("pictureBox1.InitialImage");
            pictureBox1.Location = new Point(33, 28);
            pictureBox1.Margin = new Padding(4, 6, 4, 6);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(205, 212);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // Signup
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(948, 704);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(4, 6, 4, 6);
            Name = "Signup";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Signup";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label signup_close;
        private System.Windows.Forms.Label signup_loginHere;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox signup_showPass;
        private System.Windows.Forms.Button signup_btn;
        private System.Windows.Forms.TextBox signup_username;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox signup_email;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox signup_password;
        private System.Windows.Forms.Label label8;
    }
}