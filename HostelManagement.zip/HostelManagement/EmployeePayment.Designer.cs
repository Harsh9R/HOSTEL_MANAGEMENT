﻿namespace HostelManagement
{
    partial class EmployeePayment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EmployeePayment));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            MonthDateTime = new Guna.UI2.WinForms.Guna2DateTimePicker();
            dataGridView = new DataGridView();
            btnPaySalary = new Guna.UI2.WinForms.Guna2Button();
            btnClear = new Guna.UI2.WinForms.Guna2Button();
            btnSearch = new Guna.UI2.WinForms.Guna2Button();
            txtName = new Guna.UI2.WinForms.Guna2TextBox();
            txtEmail = new Guna.UI2.WinForms.Guna2TextBox();
            txtDesignation = new Guna.UI2.WinForms.Guna2TextBox();
            txtAmount = new Guna.UI2.WinForms.Guna2TextBox();
            txtMobno = new Guna.UI2.WinForms.Guna2TextBox();
            btnExit = new Guna.UI2.WinForms.Guna2Button();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label1 = new Label();
            hmsLabel = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView).BeginInit();
            SuspendLayout();
            // 
            // MonthDateTime
            // 
            MonthDateTime.Checked = true;
            MonthDateTime.CustomizableEdges = customizableEdges1;
            MonthDateTime.Font = new Font("Segoe UI", 9F);
            MonthDateTime.Format = DateTimePickerFormat.Long;
            MonthDateTime.Location = new Point(305, 371);
            MonthDateTime.MaxDate = new DateTime(9998, 12, 31, 0, 0, 0, 0);
            MonthDateTime.MinDate = new DateTime(1753, 1, 1, 0, 0, 0, 0);
            MonthDateTime.Name = "MonthDateTime";
            MonthDateTime.ShadowDecoration.CustomizableEdges = customizableEdges2;
            MonthDateTime.Size = new Size(869, 54);
            MonthDateTime.TabIndex = 100;
            MonthDateTime.Value = new DateTime(2024, 10, 5, 16, 26, 8, 487);
            // 
            // dataGridView
            // 
            dataGridView.BackgroundColor = Color.White;
            dataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView.Location = new Point(15, 560);
            dataGridView.Name = "dataGridView";
            dataGridView.RowHeadersWidth = 62;
            dataGridView.Size = new Size(1250, 226);
            dataGridView.TabIndex = 99;
            // 
            // btnPaySalary
            // 
            btnPaySalary.BorderRadius = 15;
            btnPaySalary.CustomizableEdges = customizableEdges3;
            btnPaySalary.DisabledState.BorderColor = Color.DarkGray;
            btnPaySalary.DisabledState.CustomBorderColor = Color.DarkGray;
            btnPaySalary.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnPaySalary.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnPaySalary.FillColor = Color.Silver;
            btnPaySalary.Font = new Font("Segoe UI", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnPaySalary.ForeColor = Color.Black;
            btnPaySalary.Image = (Image)resources.GetObject("btnPaySalary.Image");
            btnPaySalary.ImageSize = new Size(30, 30);
            btnPaySalary.Location = new Point(832, 504);
            btnPaySalary.Margin = new Padding(4, 3, 4, 3);
            btnPaySalary.Name = "btnPaySalary";
            btnPaySalary.ShadowDecoration.CustomizableEdges = customizableEdges4;
            btnPaySalary.Size = new Size(163, 46);
            btnPaySalary.TabIndex = 98;
            btnPaySalary.Text = "Pay Salary";
            btnPaySalary.Click += btnPaySalary_Click;
            // 
            // btnClear
            // 
            btnClear.BorderRadius = 15;
            btnClear.CustomizableEdges = customizableEdges5;
            btnClear.DisabledState.BorderColor = Color.DarkGray;
            btnClear.DisabledState.CustomBorderColor = Color.DarkGray;
            btnClear.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnClear.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnClear.FillColor = Color.Silver;
            btnClear.Font = new Font("Segoe UI", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnClear.ForeColor = Color.Black;
            btnClear.Image = (Image)resources.GetObject("btnClear.Image");
            btnClear.ImageSize = new Size(30, 30);
            btnClear.Location = new Point(1011, 504);
            btnClear.Margin = new Padding(4, 3, 4, 3);
            btnClear.Name = "btnClear";
            btnClear.ShadowDecoration.CustomizableEdges = customizableEdges6;
            btnClear.Size = new Size(163, 46);
            btnClear.TabIndex = 97;
            btnClear.Text = "Clear";
            btnClear.Click += btnClear_Click;
            // 
            // btnSearch
            // 
            btnSearch.BorderRadius = 15;
            btnSearch.CustomizableEdges = customizableEdges7;
            btnSearch.DisabledState.BorderColor = Color.DarkGray;
            btnSearch.DisabledState.CustomBorderColor = Color.DarkGray;
            btnSearch.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnSearch.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnSearch.FillColor = Color.Silver;
            btnSearch.Font = new Font("Segoe UI", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnSearch.ForeColor = Color.Black;
            btnSearch.Image = (Image)resources.GetObject("btnSearch.Image");
            btnSearch.ImageSize = new Size(30, 30);
            btnSearch.Location = new Point(760, 115);
            btnSearch.Margin = new Padding(4, 3, 4, 3);
            btnSearch.Name = "btnSearch";
            btnSearch.ShadowDecoration.CustomizableEdges = customizableEdges8;
            btnSearch.Size = new Size(163, 46);
            btnSearch.TabIndex = 96;
            btnSearch.Text = "Search";
            btnSearch.Click += btnSearch_Click;
            // 
            // txtName
            // 
            txtName.CustomizableEdges = customizableEdges9;
            txtName.DefaultText = "";
            txtName.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtName.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtName.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtName.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtName.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtName.Font = new Font("Segoe UI", 9F);
            txtName.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtName.Location = new Point(305, 179);
            txtName.Margin = new Padding(4, 5, 4, 5);
            txtName.Name = "txtName";
            txtName.PasswordChar = '\0';
            txtName.PlaceholderText = "";
            txtName.SelectedText = "";
            txtName.ShadowDecoration.CustomizableEdges = customizableEdges10;
            txtName.Size = new Size(869, 43);
            txtName.TabIndex = 95;
            // 
            // txtEmail
            // 
            txtEmail.CustomizableEdges = customizableEdges11;
            txtEmail.DefaultText = "";
            txtEmail.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtEmail.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtEmail.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtEmail.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtEmail.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtEmail.Font = new Font("Segoe UI", 9F);
            txtEmail.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtEmail.Location = new Point(305, 240);
            txtEmail.Margin = new Padding(4, 5, 4, 5);
            txtEmail.Name = "txtEmail";
            txtEmail.PasswordChar = '\0';
            txtEmail.PlaceholderText = "";
            txtEmail.SelectedText = "";
            txtEmail.ShadowDecoration.CustomizableEdges = customizableEdges12;
            txtEmail.Size = new Size(869, 43);
            txtEmail.TabIndex = 94;
            // 
            // txtDesignation
            // 
            txtDesignation.CustomizableEdges = customizableEdges13;
            txtDesignation.DefaultText = "";
            txtDesignation.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtDesignation.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtDesignation.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtDesignation.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtDesignation.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtDesignation.Font = new Font("Segoe UI", 9F);
            txtDesignation.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtDesignation.Location = new Point(305, 309);
            txtDesignation.Margin = new Padding(4, 5, 4, 5);
            txtDesignation.Name = "txtDesignation";
            txtDesignation.PasswordChar = '\0';
            txtDesignation.PlaceholderText = "";
            txtDesignation.SelectedText = "";
            txtDesignation.ShadowDecoration.CustomizableEdges = customizableEdges14;
            txtDesignation.Size = new Size(869, 43);
            txtDesignation.TabIndex = 93;
            // 
            // txtAmount
            // 
            txtAmount.CustomizableEdges = customizableEdges15;
            txtAmount.DefaultText = "";
            txtAmount.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtAmount.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtAmount.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtAmount.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtAmount.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtAmount.Font = new Font("Segoe UI", 9F);
            txtAmount.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtAmount.Location = new Point(305, 448);
            txtAmount.Margin = new Padding(4, 5, 4, 5);
            txtAmount.Name = "txtAmount";
            txtAmount.PasswordChar = '\0';
            txtAmount.PlaceholderText = "";
            txtAmount.SelectedText = "";
            txtAmount.ShadowDecoration.CustomizableEdges = customizableEdges16;
            txtAmount.Size = new Size(869, 43);
            txtAmount.TabIndex = 92;
            // 
            // txtMobno
            // 
            txtMobno.CustomizableEdges = customizableEdges17;
            txtMobno.DefaultText = "";
            txtMobno.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtMobno.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtMobno.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtMobno.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtMobno.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtMobno.Font = new Font("Segoe UI", 9F);
            txtMobno.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtMobno.Location = new Point(305, 117);
            txtMobno.Margin = new Padding(4, 5, 4, 5);
            txtMobno.Name = "txtMobno";
            txtMobno.PasswordChar = '\0';
            txtMobno.PlaceholderText = "";
            txtMobno.SelectedText = "";
            txtMobno.ShadowDecoration.CustomizableEdges = customizableEdges18;
            txtMobno.Size = new Size(410, 43);
            txtMobno.TabIndex = 91;
            // 
            // btnExit
            // 
            btnExit.BorderRadius = 15;
            btnExit.CustomizableEdges = customizableEdges19;
            btnExit.DisabledState.BorderColor = Color.DarkGray;
            btnExit.DisabledState.CustomBorderColor = Color.DarkGray;
            btnExit.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnExit.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnExit.FillColor = Color.Purple;
            btnExit.Font = new Font("Segoe UI", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnExit.ForeColor = Color.White;
            btnExit.Image = (Image)resources.GetObject("btnExit.Image");
            btnExit.ImageSize = new Size(45, 45);
            btnExit.Location = new Point(1203, 3);
            btnExit.Margin = new Padding(4, 3, 4, 3);
            btnExit.Name = "btnExit";
            btnExit.RightToLeft = RightToLeft.No;
            btnExit.ShadowDecoration.CustomizableEdges = customizableEdges20;
            btnExit.Size = new Size(77, 72);
            btnExit.TabIndex = 90;
            btnExit.Click += btnExit_Click;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Century Gothic", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.White;
            label9.Location = new Point(90, 181);
            label9.Name = "label9";
            label9.Size = new Size(79, 25);
            label9.TabIndex = 89;
            label9.Text = "Name";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Century Gothic", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.White;
            label8.Location = new Point(91, 247);
            label8.Name = "label8";
            label8.Size = new Size(105, 25);
            label8.TabIndex = 88;
            label8.Text = "E-mail Id";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Century Gothic", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.White;
            label7.Location = new Point(91, 311);
            label7.Name = "label7";
            label7.Size = new Size(137, 25);
            label7.TabIndex = 87;
            label7.Text = "Designation";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Century Gothic", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.White;
            label6.Location = new Point(91, 384);
            label6.Name = "label6";
            label6.Size = new Size(83, 25);
            label6.TabIndex = 86;
            label6.Text = "Month";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Century Gothic", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.White;
            label5.Location = new Point(91, 454);
            label5.Name = "label5";
            label5.Size = new Size(203, 25);
            label5.TabIndex = 85;
            label5.Text = "Payment Amount";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(91, 117);
            label1.Name = "label1";
            label1.Size = new Size(181, 25);
            label1.TabIndex = 84;
            label1.Text = "Mobile Number";
            // 
            // hmsLabel
            // 
            hmsLabel.AutoSize = true;
            hmsLabel.BorderStyle = BorderStyle.Fixed3D;
            hmsLabel.Font = new Font("Agency FB", 36F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            hmsLabel.ForeColor = Color.White;
            hmsLabel.Location = new Point(12, 9);
            hmsLabel.Name = "hmsLabel";
            hmsLabel.Size = new Size(690, 90);
            hmsLabel.TabIndex = 101;
            hmsLabel.Text = "Employee Payment Details";
            // 
            // EmployeePayment
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Purple;
            ClientSize = new Size(1280, 794);
            Controls.Add(hmsLabel);
            Controls.Add(MonthDateTime);
            Controls.Add(dataGridView);
            Controls.Add(btnPaySalary);
            Controls.Add(btnClear);
            Controls.Add(btnSearch);
            Controls.Add(txtName);
            Controls.Add(txtEmail);
            Controls.Add(txtDesignation);
            Controls.Add(txtAmount);
            Controls.Add(txtMobno);
            Controls.Add(btnExit);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "EmployeePayment";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "EmployeePayment";
            Load += EmployeePayment_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Guna.UI2.WinForms.Guna2DateTimePicker MonthDateTime;
        private DataGridView dataGridView;
        private Guna.UI2.WinForms.Guna2Button btnPaySalary;
        private Guna.UI2.WinForms.Guna2Button btnClear;
        private Guna.UI2.WinForms.Guna2Button btnSearch;
        private Guna.UI2.WinForms.Guna2TextBox txtName;
        private Guna.UI2.WinForms.Guna2TextBox txtEmail;
        private Guna.UI2.WinForms.Guna2TextBox txtDesignation;
        private Guna.UI2.WinForms.Guna2TextBox txtAmount;
        private Guna.UI2.WinForms.Guna2TextBox txtMobno;
        private Guna.UI2.WinForms.Guna2Button btnExit;
        private Label label9;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label1;
        private Label hmsLabel;
    }
}