﻿namespace HostelManagement
{
    partial class UpdateDeleteStudents
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UpdateDeleteStudents));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges21 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges22 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges23 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges24 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges25 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges26 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges27 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges28 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            txtIdProof = new Guna.UI2.WinForms.Guna2TextBox();
            label2 = new Label();
            comboBoxLiving = new ComboBox();
            btnUpdate = new Guna.UI2.WinForms.Guna2Button();
            btnClear = new Guna.UI2.WinForms.Guna2Button();
            txtName = new Guna.UI2.WinForms.Guna2TextBox();
            textFather = new Guna.UI2.WinForms.Guna2TextBox();
            textMother = new Guna.UI2.WinForms.Guna2TextBox();
            txtCollege = new Guna.UI2.WinForms.Guna2TextBox();
            txtPermanent = new Guna.UI2.WinForms.Guna2TextBox();
            textEmail = new Guna.UI2.WinForms.Guna2TextBox();
            txtMobile = new Guna.UI2.WinForms.Guna2TextBox();
            btnExit = new Guna.UI2.WinForms.Guna2Button();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label1 = new Label();
            btnSearch = new Guna.UI2.WinForms.Guna2Button();
            label10 = new Label();
            txtRoomNo = new Guna.UI2.WinForms.Guna2TextBox();
            btnDelete = new Guna.UI2.WinForms.Guna2Button();
            SuspendLayout();
            // 
            // txtIdProof
            // 
            txtIdProof.CustomizableEdges = customizableEdges1;
            txtIdProof.DefaultText = "";
            txtIdProof.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtIdProof.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtIdProof.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtIdProof.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtIdProof.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtIdProof.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtIdProof.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtIdProof.Location = new Point(241, 394);
            txtIdProof.Margin = new Padding(4, 5, 4, 5);
            txtIdProof.Name = "txtIdProof";
            txtIdProof.PasswordChar = '\0';
            txtIdProof.PlaceholderText = "";
            txtIdProof.SelectedText = "";
            txtIdProof.ShadowDecoration.CustomizableEdges = customizableEdges2;
            txtIdProof.Size = new Size(869, 42);
            txtIdProof.TabIndex = 77;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.White;
            label2.Location = new Point(50, 449);
            label2.Margin = new Padding(2, 0, 2, 0);
            label2.Name = "label2";
            label2.Size = new Size(148, 25);
            label2.TabIndex = 76;
            label2.Text = "Room Number";
            // 
            // comboBoxLiving
            // 
            comboBoxLiving.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            comboBoxLiving.FormattingEnabled = true;
            comboBoxLiving.Items.AddRange(new object[] { "Yes", "No" });
            comboBoxLiving.Location = new Point(241, 521);
            comboBoxLiving.Margin = new Padding(2);
            comboBoxLiving.Name = "comboBoxLiving";
            comboBoxLiving.Size = new Size(869, 33);
            comboBoxLiving.TabIndex = 75;
            // 
            // btnUpdate
            // 
            btnUpdate.BorderRadius = 15;
            btnUpdate.CustomizableEdges = customizableEdges3;
            btnUpdate.DisabledState.BorderColor = Color.DarkGray;
            btnUpdate.DisabledState.CustomBorderColor = Color.DarkGray;
            btnUpdate.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnUpdate.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnUpdate.FillColor = Color.Silver;
            btnUpdate.Font = new Font("Segoe UI", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnUpdate.ForeColor = Color.Black;
            btnUpdate.Image = (Image)resources.GetObject("btnUpdate.Image");
            btnUpdate.ImageSize = new Size(30, 30);
            btnUpdate.Location = new Point(460, 612);
            btnUpdate.Margin = new Padding(3, 2, 3, 2);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.ShadowDecoration.CustomizableEdges = customizableEdges4;
            btnUpdate.Size = new Size(130, 37);
            btnUpdate.TabIndex = 74;
            btnUpdate.Text = "Update";
            btnUpdate.Click += btnUpdate_Click;
            // 
            // btnClear
            // 
            btnClear.BorderRadius = 15;
            btnClear.CustomizableEdges = customizableEdges5;
            btnClear.DisabledState.BorderColor = Color.DarkGray;
            btnClear.DisabledState.CustomBorderColor = Color.DarkGray;
            btnClear.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnClear.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnClear.FillColor = Color.Silver;
            btnClear.Font = new Font("Segoe UI", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnClear.ForeColor = Color.Black;
            btnClear.Image = (Image)resources.GetObject("btnClear.Image");
            btnClear.ImageSize = new Size(30, 30);
            btnClear.Location = new Point(800, 612);
            btnClear.Margin = new Padding(3, 2, 3, 2);
            btnClear.Name = "btnClear";
            btnClear.ShadowDecoration.CustomizableEdges = customizableEdges6;
            btnClear.Size = new Size(130, 37);
            btnClear.TabIndex = 73;
            btnClear.Text = "Clear";
            btnClear.Click += btnClear_Click;
            // 
            // txtName
            // 
            txtName.CustomizableEdges = customizableEdges7;
            txtName.DefaultText = "";
            txtName.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtName.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtName.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtName.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtName.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtName.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtName.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtName.Location = new Point(241, 67);
            txtName.Margin = new Padding(4, 5, 4, 5);
            txtName.Name = "txtName";
            txtName.PasswordChar = '\0';
            txtName.PlaceholderText = "";
            txtName.SelectedText = "";
            txtName.ShadowDecoration.CustomizableEdges = customizableEdges8;
            txtName.Size = new Size(869, 42);
            txtName.TabIndex = 72;
            // 
            // textFather
            // 
            textFather.CustomizableEdges = customizableEdges9;
            textFather.DefaultText = "";
            textFather.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            textFather.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            textFather.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            textFather.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            textFather.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            textFather.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textFather.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            textFather.Location = new Point(241, 117);
            textFather.Margin = new Padding(4, 5, 4, 5);
            textFather.Name = "textFather";
            textFather.PasswordChar = '\0';
            textFather.PlaceholderText = "";
            textFather.SelectedText = "";
            textFather.ShadowDecoration.CustomizableEdges = customizableEdges10;
            textFather.Size = new Size(869, 42);
            textFather.TabIndex = 71;
            textFather.TextChanged += guna2TextBox7_TextChanged;
            // 
            // textMother
            // 
            textMother.CustomizableEdges = customizableEdges11;
            textMother.DefaultText = "";
            textMother.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            textMother.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            textMother.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            textMother.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            textMother.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            textMother.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textMother.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            textMother.Location = new Point(241, 168);
            textMother.Margin = new Padding(4, 5, 4, 5);
            textMother.Name = "textMother";
            textMother.PasswordChar = '\0';
            textMother.PlaceholderText = "";
            textMother.SelectedText = "";
            textMother.ShadowDecoration.CustomizableEdges = customizableEdges12;
            textMother.Size = new Size(869, 42);
            textMother.TabIndex = 70;
            // 
            // txtCollege
            // 
            txtCollege.CustomizableEdges = customizableEdges13;
            txtCollege.DefaultText = "";
            txtCollege.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtCollege.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtCollege.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtCollege.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtCollege.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtCollege.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtCollege.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtCollege.Location = new Point(241, 332);
            txtCollege.Margin = new Padding(4, 5, 4, 5);
            txtCollege.Name = "txtCollege";
            txtCollege.PasswordChar = '\0';
            txtCollege.PlaceholderText = "";
            txtCollege.SelectedText = "";
            txtCollege.ShadowDecoration.CustomizableEdges = customizableEdges14;
            txtCollege.Size = new Size(869, 42);
            txtCollege.TabIndex = 69;
            // 
            // txtPermanent
            // 
            txtPermanent.CustomizableEdges = customizableEdges15;
            txtPermanent.DefaultText = "";
            txtPermanent.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtPermanent.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtPermanent.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtPermanent.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtPermanent.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPermanent.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtPermanent.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPermanent.Location = new Point(241, 273);
            txtPermanent.Margin = new Padding(4, 5, 4, 5);
            txtPermanent.Name = "txtPermanent";
            txtPermanent.PasswordChar = '\0';
            txtPermanent.PlaceholderText = "";
            txtPermanent.SelectedText = "";
            txtPermanent.ShadowDecoration.CustomizableEdges = customizableEdges16;
            txtPermanent.Size = new Size(869, 42);
            txtPermanent.TabIndex = 68;
            // 
            // textEmail
            // 
            textEmail.CustomizableEdges = customizableEdges17;
            textEmail.DefaultText = "";
            textEmail.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            textEmail.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            textEmail.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            textEmail.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            textEmail.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            textEmail.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textEmail.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            textEmail.Location = new Point(241, 221);
            textEmail.Margin = new Padding(4, 5, 4, 5);
            textEmail.Name = "textEmail";
            textEmail.PasswordChar = '\0';
            textEmail.PlaceholderText = "";
            textEmail.SelectedText = "";
            textEmail.ShadowDecoration.CustomizableEdges = customizableEdges18;
            textEmail.Size = new Size(869, 42);
            textEmail.TabIndex = 67;
            textEmail.TextChanged += guna2TextBox2_TextChanged;
            // 
            // txtMobile
            // 
            txtMobile.CustomizableEdges = customizableEdges19;
            txtMobile.DefaultText = "";
            txtMobile.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtMobile.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtMobile.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtMobile.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtMobile.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtMobile.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtMobile.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtMobile.Location = new Point(241, 15);
            txtMobile.Margin = new Padding(4, 5, 4, 5);
            txtMobile.Name = "txtMobile";
            txtMobile.PasswordChar = '\0';
            txtMobile.PlaceholderText = "";
            txtMobile.SelectedText = "";
            txtMobile.ShadowDecoration.CustomizableEdges = customizableEdges20;
            txtMobile.Size = new Size(418, 42);
            txtMobile.TabIndex = 66;
            // 
            // btnExit
            // 
            btnExit.BorderRadius = 15;
            btnExit.CustomizableEdges = customizableEdges21;
            btnExit.DisabledState.BorderColor = Color.DarkGray;
            btnExit.DisabledState.CustomBorderColor = Color.DarkGray;
            btnExit.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnExit.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnExit.FillColor = Color.Purple;
            btnExit.Font = new Font("Segoe UI", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnExit.ForeColor = Color.White;
            btnExit.Image = (Image)resources.GetObject("btnExit.Image");
            btnExit.ImageSize = new Size(45, 45);
            btnExit.Location = new Point(1125, -1);
            btnExit.Margin = new Padding(3, 2, 3, 2);
            btnExit.Name = "btnExit";
            btnExit.RightToLeft = RightToLeft.No;
            btnExit.ShadowDecoration.CustomizableEdges = customizableEdges22;
            btnExit.Size = new Size(62, 58);
            btnExit.TabIndex = 65;
            btnExit.Click += btnExit_Click;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.White;
            label9.Location = new Point(47, 67);
            label9.Margin = new Padding(2, 0, 2, 0);
            label9.Name = "label9";
            label9.Size = new Size(68, 25);
            label9.TabIndex = 64;
            label9.Text = "Name";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.White;
            label8.Location = new Point(47, 117);
            label8.Margin = new Padding(2, 0, 2, 0);
            label8.Name = "label8";
            label8.Size = new Size(136, 25);
            label8.TabIndex = 63;
            label8.Text = "Father Name";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.White;
            label7.Location = new Point(47, 168);
            label7.Margin = new Padding(2, 0, 2, 0);
            label7.Name = "label7";
            label7.Size = new Size(141, 25);
            label7.TabIndex = 62;
            label7.Text = "Mother Name";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.White;
            label6.Location = new Point(50, 221);
            label6.Margin = new Padding(2, 0, 2, 0);
            label6.Name = "label6";
            label6.Size = new Size(97, 25);
            label6.TabIndex = 61;
            label6.Text = "E-mail Id";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.White;
            label5.Location = new Point(27, 273);
            label5.Margin = new Padding(2, 0, 2, 0);
            label5.Name = "label5";
            label5.Size = new Size(208, 25);
            label5.TabIndex = 60;
            label5.Text = " Permanent Address";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.White;
            label4.Location = new Point(47, 332);
            label4.Margin = new Padding(2, 0, 2, 0);
            label4.Name = "label4";
            label4.Size = new Size(148, 25);
            label4.TabIndex = 59;
            label4.Text = "College Name";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.White;
            label3.Location = new Point(47, 394);
            label3.Margin = new Padding(2, 0, 2, 0);
            label3.Name = "label3";
            label3.Size = new Size(87, 25);
            label3.TabIndex = 58;
            label3.Text = "Id Proof";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(42, 23);
            label1.Margin = new Padding(2, 0, 2, 0);
            label1.Name = "label1";
            label1.Size = new Size(157, 25);
            label1.TabIndex = 57;
            label1.Text = "Mobile Number";
            // 
            // btnSearch
            // 
            btnSearch.BorderRadius = 15;
            btnSearch.CustomizableEdges = customizableEdges23;
            btnSearch.DisabledState.BorderColor = Color.DarkGray;
            btnSearch.DisabledState.CustomBorderColor = Color.DarkGray;
            btnSearch.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnSearch.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnSearch.FillColor = Color.Silver;
            btnSearch.Font = new Font("Segoe UI", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnSearch.ForeColor = Color.Black;
            btnSearch.Image = (Image)resources.GetObject("btnSearch.Image");
            btnSearch.ImageSize = new Size(30, 30);
            btnSearch.Location = new Point(713, 15);
            btnSearch.Margin = new Padding(3, 2, 3, 2);
            btnSearch.Name = "btnSearch";
            btnSearch.ShadowDecoration.CustomizableEdges = customizableEdges24;
            btnSearch.Size = new Size(130, 37);
            btnSearch.TabIndex = 78;
            btnSearch.Text = "Search";
            btnSearch.Click += btnSearch_Click;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label10.ForeColor = Color.White;
            label10.Location = new Point(42, 521);
            label10.Margin = new Padding(2, 0, 2, 0);
            label10.Name = "label10";
            label10.Size = new Size(137, 25);
            label10.TabIndex = 79;
            label10.Text = "Living Status";
            // 
            // txtRoomNo
            // 
            txtRoomNo.CustomizableEdges = customizableEdges25;
            txtRoomNo.DefaultText = "";
            txtRoomNo.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtRoomNo.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtRoomNo.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtRoomNo.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtRoomNo.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtRoomNo.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtRoomNo.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtRoomNo.Location = new Point(241, 449);
            txtRoomNo.Margin = new Padding(4, 5, 4, 5);
            txtRoomNo.Name = "txtRoomNo";
            txtRoomNo.PasswordChar = '\0';
            txtRoomNo.PlaceholderText = "";
            txtRoomNo.SelectedText = "";
            txtRoomNo.ShadowDecoration.CustomizableEdges = customizableEdges26;
            txtRoomNo.Size = new Size(869, 42);
            txtRoomNo.TabIndex = 80;
            // 
            // btnDelete
            // 
            btnDelete.BorderRadius = 15;
            btnDelete.CustomizableEdges = customizableEdges27;
            btnDelete.DisabledState.BorderColor = Color.DarkGray;
            btnDelete.DisabledState.CustomBorderColor = Color.DarkGray;
            btnDelete.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnDelete.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnDelete.FillColor = Color.Silver;
            btnDelete.Font = new Font("Segoe UI", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnDelete.ForeColor = Color.Black;
            btnDelete.Image = (Image)resources.GetObject("btnDelete.Image");
            btnDelete.ImageSize = new Size(30, 30);
            btnDelete.Location = new Point(623, 612);
            btnDelete.Margin = new Padding(3, 2, 3, 2);
            btnDelete.Name = "btnDelete";
            btnDelete.ShadowDecoration.CustomizableEdges = customizableEdges28;
            btnDelete.Size = new Size(130, 37);
            btnDelete.TabIndex = 81;
            btnDelete.Text = "Delete";
            btnDelete.Click += btnDelete_Click;
            // 
            // UpdateDeleteStudents
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Purple;
            ClientSize = new Size(1187, 724);
            Controls.Add(btnDelete);
            Controls.Add(txtRoomNo);
            Controls.Add(label10);
            Controls.Add(btnSearch);
            Controls.Add(txtIdProof);
            Controls.Add(label2);
            Controls.Add(comboBoxLiving);
            Controls.Add(btnUpdate);
            Controls.Add(btnClear);
            Controls.Add(txtName);
            Controls.Add(textFather);
            Controls.Add(textMother);
            Controls.Add(txtCollege);
            Controls.Add(txtPermanent);
            Controls.Add(textEmail);
            Controls.Add(txtMobile);
            Controls.Add(btnExit);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(2);
            Name = "UpdateDeleteStudents";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "UpdateDeleteStudents";
            Load += UpdateDeleteStudents_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Guna.UI2.WinForms.Guna2TextBox txtIdProof;
        private Label label2;
        private ComboBox comboBoxLiving;
        private Guna.UI2.WinForms.Guna2Button btnUpdate;
        private Guna.UI2.WinForms.Guna2Button btnClear;
        private Guna.UI2.WinForms.Guna2TextBox txtName;
        private Guna.UI2.WinForms.Guna2TextBox textFather;
        private Guna.UI2.WinForms.Guna2TextBox textMother;
        private Guna.UI2.WinForms.Guna2TextBox txtCollege;
        private Guna.UI2.WinForms.Guna2TextBox txtPermanent;
        private Guna.UI2.WinForms.Guna2TextBox textEmail;
        private Guna.UI2.WinForms.Guna2TextBox txtMobile;
        private Guna.UI2.WinForms.Guna2Button btnExit;
        private Label label9;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label1;
        private Guna.UI2.WinForms.Guna2Button btnSearch;
        private Label label10;
        private Guna.UI2.WinForms.Guna2TextBox txtRoomNo;
        private Guna.UI2.WinForms.Guna2Button btnDelete;
    }
}