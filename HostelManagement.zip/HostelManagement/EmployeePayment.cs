﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HostelManagement
{
    public partial class EmployeePayment : Form
    {
        function fn = new function();
        String query;
        public EmployeePayment()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        private void EmployeePayment_Load(object sender, EventArgs e)
        {
            this.Location = new Point(350, 170);
            MonthDateTime.Format = DateTimePickerFormat.Custom;
            MonthDateTime.CustomFormat = "MMMM yyyy"; //"dd-MM-yyyy" salary ma date month che kmk salary month wise apvani hoy etle 
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (txtMobno.Text != " ") //!="", aetle not equal too null
            {
                query = "select ename,eemail,edesignation from newEmployee where emobile=" + txtMobno.Text + " ";
                DataSet ds = fn.getData(query);

                if (ds.Tables[0].Rows.Count != 0)
                {
                    txtName.Text = ds.Tables[0].Rows[0][0].ToString();
                    txtEmail.Text = ds.Tables[0].Rows[0][1].ToString();
                    txtDesignation.Text = ds.Tables[0].Rows[0][2].ToString();

                    setDataGrid(Int64.Parse(txtMobno.Text));
                }
                else
                {
                    MessageBox.Show("No Record Exist.", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
            }
            else
            {
                MessageBox.Show("Enter Some Data.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        public void setDataGrid(Int64 mobile) // this is for datagridview ma employee ni all salary paid ni hostory ave
        {
            query = "select * from employeeSalary where mobileNo=" + mobile + " ";
            DataSet ds = fn.getData(query);
            dataGridView.DataSource = ds.Tables[0];
        }

        private void btnPaySalary_Click(object sender, EventArgs e)
        {
            if (txtMobno.Text != "" && txtAmount.Text != "")
            {
                query = "select * from employeeSalary where mobileNo=" + txtMobno.Text + "  and fmonth='" + MonthDateTime.Text + "'  ";
                DataSet ds = fn.getData(query);
                if (ds.Tables[0].Rows.Count == 0)
                {
                    Int64 mobile = Int64.Parse(txtMobno.Text);
                    String month = MonthDateTime.Text;
                    Int64 amount = Int64.Parse(txtAmount.Text);

                    query = "insert into employeeSalary values (" + mobile + ",'" + month + "'," + amount + ") ";
                    fn.setData(query, "Salary for month" + MonthDateTime.Text + "is Also Paid.");
                    setDataGrid(mobile);
                }
                else
                {
                    MessageBox.Show("Payment of " + MonthDateTime.Text + " is Done.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearAll();
        }
        public void ClearAll()
        {
            txtMobno.Clear();
            txtName.Clear();
            txtEmail.Clear();
            txtDesignation.Clear();
            txtAmount.Clear();
            MonthDateTime.ResetText();
            dataGridView.DataSource = 0;
        }
    }
}
