﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HostelManagement
{

    public partial class UpdateDeleteStudents : Form
    {
        function fn = new function();
        String query;

        public UpdateDeleteStudents()
        {
            InitializeComponent();
        }

        private void UpdateDeleteStudents_Load(object sender, EventArgs e)
        {
            this.Location = new Point(350, 170);
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();

        }
        private void clearAll()
        {
            txtMobile.Clear();
            txtName.Clear();
            textFather.Clear();
            textMother.Clear();
            textEmail.Clear();
            txtPermanent.Clear();
            txtCollege.Clear();
            txtIdProof.Clear();
            txtRoomNo.Clear();
            comboBoxLiving.SelectedIndex = -1;

        }

        private void guna2TextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void guna2TextBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            clearAll();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            query = "select * from newStudent where mobile=" + txtMobile.Text + "";
            DataSet ds = fn.getData(query);

            if (ds.Tables[0].Rows.Count != 0)
            {
                txtName.Text = ds.Tables[0].Rows[0][2].ToString();
                textFather.Text = ds.Tables[0].Rows[0][3].ToString();
                textMother.Text = ds.Tables[0].Rows[0][4].ToString();
                textEmail.Text = ds.Tables[0].Rows[0][5].ToString();
                txtPermanent.Text = ds.Tables[0].Rows[0][6].ToString();
                txtCollege.Text = ds.Tables[0].Rows[0][7].ToString();
                txtIdProof.Text = ds.Tables[0].Rows[0][8].ToString();
                txtRoomNo.Text = ds.Tables[0].Rows[0][9].ToString();
                comboBoxLiving.Text = ds.Tables[0].Rows[0][10].ToString();

            }
            else
            {
                clearAll();
                MessageBox.Show("No Record with this Mobile No Exists.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Int64 mobile = Int64.Parse(txtMobile.Text);
            String name = txtName.Text;
            String fname = textFather.Text;
            String mname = textMother.Text;
            String email = textEmail.Text;
            String paddress = txtPermanent.Text;
            String college = txtCollege.Text;
            String idproof = txtIdProof.Text;
            Int64 roomno = Int64.Parse(txtRoomNo.Text);
            String living = comboBoxLiving.Text;

            query = "update newStudent set name ='" + name + "',fname ='" + fname + "',mname ='" + mname + "',email ='" + email + "',paddress ='" + paddress + "',college ='" + college + "',idproof ='" + idproof + "',roomno ='" + roomno + "',living ='" + living + "'where mobile = " + mobile + " update rooms set Booked='" + living + "' where roomno =" + roomno + "";
            fn.setData(query, "Data Updation Successful");

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are Your Sure?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes) 
            {
                query = "delete from newStudent where mobile = " + txtMobile.Text + "";
                fn.setData(query, "Student Record Deleated ");
                clearAll();
            }
         
        }
    }
}
