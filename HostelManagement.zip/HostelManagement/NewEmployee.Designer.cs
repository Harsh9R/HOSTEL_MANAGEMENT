﻿namespace HostelManagement
{
    partial class NewEmployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NewEmployee));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            label1 = new Label();
            btnExit = new Guna.UI2.WinForms.Guna2Button();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            txtMobile = new Guna.UI2.WinForms.Guna2TextBox();
            txtEmail = new Guna.UI2.WinForms.Guna2TextBox();
            txtAddr = new Guna.UI2.WinForms.Guna2TextBox();
            txtUid = new Guna.UI2.WinForms.Guna2TextBox();
            txtmName = new Guna.UI2.WinForms.Guna2TextBox();
            txtfName = new Guna.UI2.WinForms.Guna2TextBox();
            txtName = new Guna.UI2.WinForms.Guna2TextBox();
            btnclr = new Guna.UI2.WinForms.Guna2Button();
            searchBtn = new Guna.UI2.WinForms.Guna2Button();
            comboBox1 = new ComboBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.FromArgb(255, 255, 192);
            label1.BorderStyle = BorderStyle.Fixed3D;
            label1.Font = new Font("Rockwell", 20F, FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Black;
            label1.Location = new Point(436, 13);
            label1.Name = "label1";
            label1.Size = new Size(515, 48);
            label1.TabIndex = 0;
            label1.Text = "New Employee Registration";
            label1.Click += label1_Click;
            // 
            // btnExit
            // 
            btnExit.BorderRadius = 15;
            btnExit.CustomizableEdges = customizableEdges1;
            btnExit.DisabledState.BorderColor = Color.DarkGray;
            btnExit.DisabledState.CustomBorderColor = Color.DarkGray;
            btnExit.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnExit.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnExit.FillColor = Color.Purple;
            btnExit.Font = new Font("Segoe UI", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnExit.ForeColor = Color.White;
            btnExit.Image = (Image)resources.GetObject("btnExit.Image");
            btnExit.ImageSize = new Size(35, 35);
            btnExit.Location = new Point(1199, 3);
            btnExit.Margin = new Padding(4, 3, 4, 3);
            btnExit.Name = "btnExit";
            btnExit.ShadowDecoration.CustomizableEdges = customizableEdges2;
            btnExit.Size = new Size(77, 58);
            btnExit.TabIndex = 23;
            btnExit.Click += btnExit_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Century Gothic", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.White;
            label2.Location = new Point(91, 112);
            label2.Name = "label2";
            label2.Size = new Size(181, 25);
            label2.TabIndex = 24;
            label2.Text = "Mobile Number";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Century Gothic", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.White;
            label3.Location = new Point(91, 593);
            label3.Name = "label3";
            label3.Size = new Size(137, 25);
            label3.TabIndex = 25;
            label3.Text = "Designation";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Century Gothic", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.White;
            label4.Location = new Point(91, 522);
            label4.Name = "label4";
            label4.Size = new Size(113, 25);
            label4.TabIndex = 26;
            label4.Text = "Unique Id";
            label4.Click += label4_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Century Gothic", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.White;
            label5.Location = new Point(91, 449);
            label5.Name = "label5";
            label5.Size = new Size(98, 25);
            label5.TabIndex = 27;
            label5.Text = "Address";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Century Gothic", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.White;
            label6.Location = new Point(91, 379);
            label6.Name = "label6";
            label6.Size = new Size(105, 25);
            label6.TabIndex = 28;
            label6.Text = "E-mail Id";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Century Gothic", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.White;
            label7.Location = new Point(91, 306);
            label7.Name = "label7";
            label7.Size = new Size(164, 25);
            label7.TabIndex = 29;
            label7.Text = "Mother Name";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Century Gothic", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.White;
            label8.Location = new Point(91, 242);
            label8.Name = "label8";
            label8.Size = new Size(153, 25);
            label8.TabIndex = 30;
            label8.Text = "Father Name";
            label8.Click += label8_Click;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Century Gothic", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.White;
            label9.Location = new Point(91, 176);
            label9.Name = "label9";
            label9.Size = new Size(79, 25);
            label9.TabIndex = 31;
            label9.Text = "Name";
            // 
            // txtMobile
            // 
            txtMobile.CustomizableEdges = customizableEdges3;
            txtMobile.DefaultText = "";
            txtMobile.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtMobile.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtMobile.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtMobile.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtMobile.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtMobile.Font = new Font("Segoe UI", 9F);
            txtMobile.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtMobile.Location = new Point(319, 103);
            txtMobile.Margin = new Padding(4, 5, 4, 5);
            txtMobile.Name = "txtMobile";
            txtMobile.PasswordChar = '\0';
            txtMobile.PlaceholderText = "";
            txtMobile.SelectedText = "";
            txtMobile.ShadowDecoration.CustomizableEdges = customizableEdges4;
            txtMobile.Size = new Size(869, 43);
            txtMobile.TabIndex = 32;
            txtMobile.TextChanged += TextBox1_TextChanged;
            // 
            // txtEmail
            // 
            txtEmail.CustomizableEdges = customizableEdges5;
            txtEmail.DefaultText = "";
            txtEmail.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtEmail.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtEmail.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtEmail.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtEmail.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtEmail.Font = new Font("Segoe UI", 9F);
            txtEmail.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtEmail.Location = new Point(319, 371);
            txtEmail.Margin = new Padding(4, 5, 4, 5);
            txtEmail.Name = "txtEmail";
            txtEmail.PasswordChar = '\0';
            txtEmail.PlaceholderText = "";
            txtEmail.SelectedText = "";
            txtEmail.ShadowDecoration.CustomizableEdges = customizableEdges6;
            txtEmail.Size = new Size(869, 43);
            txtEmail.TabIndex = 33;
            // 
            // txtAddr
            // 
            txtAddr.CustomizableEdges = customizableEdges7;
            txtAddr.DefaultText = "";
            txtAddr.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtAddr.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtAddr.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtAddr.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtAddr.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtAddr.Font = new Font("Segoe UI", 9F);
            txtAddr.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtAddr.Location = new Point(319, 440);
            txtAddr.Margin = new Padding(4, 5, 4, 5);
            txtAddr.Name = "txtAddr";
            txtAddr.PasswordChar = '\0';
            txtAddr.PlaceholderText = "";
            txtAddr.SelectedText = "";
            txtAddr.ShadowDecoration.CustomizableEdges = customizableEdges8;
            txtAddr.Size = new Size(869, 43);
            txtAddr.TabIndex = 34;
            // 
            // txtUid
            // 
            txtUid.CustomizableEdges = customizableEdges9;
            txtUid.DefaultText = "";
            txtUid.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtUid.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtUid.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtUid.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtUid.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtUid.Font = new Font("Segoe UI", 9F);
            txtUid.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtUid.Location = new Point(319, 517);
            txtUid.Margin = new Padding(4, 5, 4, 5);
            txtUid.Name = "txtUid";
            txtUid.PasswordChar = '\0';
            txtUid.PlaceholderText = "";
            txtUid.SelectedText = "";
            txtUid.ShadowDecoration.CustomizableEdges = customizableEdges10;
            txtUid.Size = new Size(869, 43);
            txtUid.TabIndex = 35;
            // 
            // txtmName
            // 
            txtmName.CustomizableEdges = customizableEdges11;
            txtmName.DefaultText = "";
            txtmName.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtmName.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtmName.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtmName.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtmName.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtmName.Font = new Font("Segoe UI", 9F);
            txtmName.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtmName.Location = new Point(319, 301);
            txtmName.Margin = new Padding(4, 5, 4, 5);
            txtmName.Name = "txtmName";
            txtmName.PasswordChar = '\0';
            txtmName.PlaceholderText = "";
            txtmName.SelectedText = "";
            txtmName.ShadowDecoration.CustomizableEdges = customizableEdges12;
            txtmName.Size = new Size(869, 43);
            txtmName.TabIndex = 37;
            // 
            // txtfName
            // 
            txtfName.CustomizableEdges = customizableEdges13;
            txtfName.DefaultText = "";
            txtfName.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtfName.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtfName.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtfName.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtfName.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtfName.Font = new Font("Segoe UI", 9F);
            txtfName.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtfName.Location = new Point(319, 229);
            txtfName.Margin = new Padding(4, 5, 4, 5);
            txtfName.Name = "txtfName";
            txtfName.PasswordChar = '\0';
            txtfName.PlaceholderText = "";
            txtfName.SelectedText = "";
            txtfName.ShadowDecoration.CustomizableEdges = customizableEdges14;
            txtfName.Size = new Size(869, 43);
            txtfName.TabIndex = 38;
            // 
            // txtName
            // 
            txtName.CustomizableEdges = customizableEdges15;
            txtName.DefaultText = "";
            txtName.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtName.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtName.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtName.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtName.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtName.Font = new Font("Segoe UI", 9F);
            txtName.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtName.Location = new Point(319, 166);
            txtName.Margin = new Padding(4, 5, 4, 5);
            txtName.Name = "txtName";
            txtName.PasswordChar = '\0';
            txtName.PlaceholderText = "";
            txtName.SelectedText = "";
            txtName.ShadowDecoration.CustomizableEdges = customizableEdges16;
            txtName.Size = new Size(869, 43);
            txtName.TabIndex = 39;
            // 
            // btnclr
            // 
            btnclr.BorderRadius = 15;
            btnclr.CustomizableEdges = customizableEdges17;
            btnclr.DisabledState.BorderColor = Color.DarkGray;
            btnclr.DisabledState.CustomBorderColor = Color.DarkGray;
            btnclr.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnclr.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnclr.FillColor = Color.Silver;
            btnclr.Font = new Font("Segoe UI", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnclr.ForeColor = Color.Black;
            btnclr.Image = (Image)resources.GetObject("btnclr.Image");
            btnclr.ImageSize = new Size(30, 30);
            btnclr.Location = new Point(944, 650);
            btnclr.Margin = new Padding(4, 3, 4, 3);
            btnclr.Name = "btnclr";
            btnclr.ShadowDecoration.CustomizableEdges = customizableEdges18;
            btnclr.Size = new Size(163, 46);
            btnclr.TabIndex = 40;
            btnclr.Text = "Clear";
            btnclr.Click += btnclr_Click;
            // 
            // searchBtn
            // 
            searchBtn.BorderRadius = 15;
            searchBtn.CustomizableEdges = customizableEdges19;
            searchBtn.DisabledState.BorderColor = Color.DarkGray;
            searchBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            searchBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            searchBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            searchBtn.FillColor = Color.Silver;
            searchBtn.Font = new Font("Segoe UI", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            searchBtn.ForeColor = Color.Black;
            searchBtn.Image = (Image)resources.GetObject("searchBtn.Image");
            searchBtn.ImageSize = new Size(30, 30);
            searchBtn.Location = new Point(713, 650);
            searchBtn.Margin = new Padding(4, 3, 4, 3);
            searchBtn.Name = "searchBtn";
            searchBtn.ShadowDecoration.CustomizableEdges = customizableEdges20;
            searchBtn.Size = new Size(163, 46);
            searchBtn.TabIndex = 41;
            searchBtn.Text = "Save";
            searchBtn.Click += searchBtn_Click;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Hostel Incharge", "Mess Staff", "Cleaning Staff", "Accounts Manager", "Event Organizer" });
            comboBox1.Location = new Point(319, 587);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(869, 33);
            comboBox1.TabIndex = 42;
            // 
            // NewEmployee
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Purple;
            ClientSize = new Size(1280, 750);
            Controls.Add(comboBox1);
            Controls.Add(searchBtn);
            Controls.Add(btnclr);
            Controls.Add(txtName);
            Controls.Add(txtfName);
            Controls.Add(txtmName);
            Controls.Add(txtUid);
            Controls.Add(txtAddr);
            Controls.Add(txtEmail);
            Controls.Add(txtMobile);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(btnExit);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "NewEmployee";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "x";
            Load += NewEmployee_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Guna.UI2.WinForms.Guna2Button btnExit;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Guna.UI2.WinForms.Guna2TextBox txtMobile;
        private Guna.UI2.WinForms.Guna2TextBox txtEmail;
        private Guna.UI2.WinForms.Guna2TextBox txtAddr;
        private Guna.UI2.WinForms.Guna2TextBox txtUid;
        private Guna.UI2.WinForms.Guna2TextBox txtmName;
        private Guna.UI2.WinForms.Guna2TextBox txtfName;
        private Guna.UI2.WinForms.Guna2TextBox txtName;
        private Guna.UI2.WinForms.Guna2Button btnclr;
        private Guna.UI2.WinForms.Guna2Button searchBtn;
        private ComboBox comboBox1;
    }
}