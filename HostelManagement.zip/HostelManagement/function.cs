﻿using System.Data.SqlClient;
using System;
using System.Data;
using System.Windows.Forms;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace HostelManagement
{
    internal class function
    {       
        protected SqlConnection getConnection()
        {
            SqlConnection con = new SqlConnection();
            //con.ConnectionString = "Data Source=UMANGSP;database=hostel;integrated security=True";
            //con.ConnectionString = "Data Source=UMANGSP;Initial Catalog=hostel;Integrated Security=True;"; //ssms string

            //con.ConnectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\ABC\\Downloads\\inner database\\HostelManagement\\Hostel.mdf\";Integrated Security=True";
            //            con.ConnectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\ABC\\Downloads\\inner database\\HostelManagement\\Hostel.mdf\";Integrated Security=True";
            con.ConnectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\rutvi\\Music\\projct\\HostelManagement\\Hostel.mdf;Integrated Security=True";

            //            con.ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\ABC\Downloads\inner database\HostelManagement\Hostel.mdf;Integrated Security=True";

            return con;
        }

        public DataSet getData(string query)
        {
            SqlConnection con = getConnection();
            SqlCommand cmd = new SqlCommand(query, con);  // Pass the query and connection
            SqlDataAdapter da = new SqlDataAdapter(cmd);  // Pass the SqlCommand to SqlDataAdapter
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;
        }
        public void setData(string query, string msg)
        {
            using (SqlConnection con = getConnection())
            {
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show(msg, "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }
    }
}
