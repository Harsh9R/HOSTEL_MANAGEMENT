﻿namespace HostelManagement
{
    partial class StudentFees
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(StudentFees));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            txtName = new Guna.UI2.WinForms.Guna2TextBox();
            txtEmailId = new Guna.UI2.WinForms.Guna2TextBox();
            txtRoomNo = new Guna.UI2.WinForms.Guna2TextBox();
            txtAmount = new Guna.UI2.WinForms.Guna2TextBox();
            txtMobile = new Guna.UI2.WinForms.Guna2TextBox();
            btnExit = new Guna.UI2.WinForms.Guna2Button();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label1 = new Label();
            btnSearch = new Guna.UI2.WinForms.Guna2Button();
            btnClear = new Guna.UI2.WinForms.Guna2Button();
            btnPay = new Guna.UI2.WinForms.Guna2Button();
            dataGridView1 = new DataGridView();
            dateTimePicker = new Guna.UI2.WinForms.Guna2DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // txtName
            // 
            txtName.CustomizableEdges = customizableEdges1;
            txtName.DefaultText = "";
            txtName.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtName.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtName.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtName.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtName.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtName.Font = new Font("Segoe UI", 9F);
            txtName.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtName.Location = new Point(209, 77);
            txtName.Margin = new Padding(3, 4, 3, 4);
            txtName.Name = "txtName";
            txtName.PasswordChar = '\0';
            txtName.PlaceholderText = "";
            txtName.SelectedText = "";
            txtName.ShadowDecoration.CustomizableEdges = customizableEdges2;
            txtName.Size = new Size(695, 34);
            txtName.TabIndex = 64;
            // 
            // txtEmailId
            // 
            txtEmailId.CustomizableEdges = customizableEdges3;
            txtEmailId.DefaultText = "";
            txtEmailId.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtEmailId.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtEmailId.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtEmailId.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtEmailId.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtEmailId.Font = new Font("Segoe UI", 9F);
            txtEmailId.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtEmailId.Location = new Point(209, 126);
            txtEmailId.Margin = new Padding(3, 4, 3, 4);
            txtEmailId.Name = "txtEmailId";
            txtEmailId.PasswordChar = '\0';
            txtEmailId.PlaceholderText = "";
            txtEmailId.SelectedText = "";
            txtEmailId.ShadowDecoration.CustomizableEdges = customizableEdges4;
            txtEmailId.Size = new Size(695, 34);
            txtEmailId.TabIndex = 63;
            // 
            // txtRoomNo
            // 
            txtRoomNo.CustomizableEdges = customizableEdges5;
            txtRoomNo.DefaultText = "";
            txtRoomNo.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtRoomNo.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtRoomNo.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtRoomNo.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtRoomNo.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtRoomNo.Font = new Font("Segoe UI", 9F);
            txtRoomNo.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtRoomNo.Location = new Point(209, 181);
            txtRoomNo.Margin = new Padding(3, 4, 3, 4);
            txtRoomNo.Name = "txtRoomNo";
            txtRoomNo.PasswordChar = '\0';
            txtRoomNo.PlaceholderText = "";
            txtRoomNo.SelectedText = "";
            txtRoomNo.ShadowDecoration.CustomizableEdges = customizableEdges6;
            txtRoomNo.Size = new Size(695, 34);
            txtRoomNo.TabIndex = 62;
            // 
            // txtAmount
            // 
            txtAmount.CustomizableEdges = customizableEdges7;
            txtAmount.DefaultText = "";
            txtAmount.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtAmount.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtAmount.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtAmount.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtAmount.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtAmount.Font = new Font("Segoe UI", 9F);
            txtAmount.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtAmount.Location = new Point(209, 292);
            txtAmount.Margin = new Padding(3, 4, 3, 4);
            txtAmount.Name = "txtAmount";
            txtAmount.PasswordChar = '\0';
            txtAmount.PlaceholderText = "";
            txtAmount.SelectedText = "";
            txtAmount.ShadowDecoration.CustomizableEdges = customizableEdges8;
            txtAmount.Size = new Size(695, 34);
            txtAmount.TabIndex = 61;
            // 
            // txtMobile
            // 
            txtMobile.CustomizableEdges = customizableEdges9;
            txtMobile.DefaultText = "";
            txtMobile.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtMobile.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtMobile.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtMobile.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtMobile.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtMobile.Font = new Font("Segoe UI", 9F);
            txtMobile.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtMobile.Location = new Point(209, 27);
            txtMobile.Margin = new Padding(3, 4, 3, 4);
            txtMobile.Name = "txtMobile";
            txtMobile.PasswordChar = '\0';
            txtMobile.PlaceholderText = "";
            txtMobile.SelectedText = "";
            txtMobile.ShadowDecoration.CustomizableEdges = customizableEdges10;
            txtMobile.Size = new Size(328, 34);
            txtMobile.TabIndex = 59;
            // 
            // btnExit
            // 
            btnExit.BorderRadius = 15;
            btnExit.CustomizableEdges = customizableEdges11;
            btnExit.DisabledState.BorderColor = Color.DarkGray;
            btnExit.DisabledState.CustomBorderColor = Color.DarkGray;
            btnExit.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnExit.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnExit.FillColor = Color.Purple;
            btnExit.Font = new Font("Segoe UI", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnExit.ForeColor = Color.White;
            btnExit.Image = (Image)resources.GetObject("btnExit.Image");
            btnExit.ImageSize = new Size(45, 45);
            btnExit.Location = new Point(944, 2);
            btnExit.Margin = new Padding(3, 2, 3, 2);
            btnExit.Name = "btnExit";
            btnExit.RightToLeft = RightToLeft.No;
            btnExit.ShadowDecoration.CustomizableEdges = customizableEdges12;
            btnExit.Size = new Size(62, 58);
            btnExit.TabIndex = 58;
            btnExit.Click += btnExit_Click;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Microsoft Sans Serif", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.White;
            label9.Location = new Point(37, 78);
            label9.Margin = new Padding(2, 0, 2, 0);
            label9.Name = "label9";
            label9.Size = new Size(61, 24);
            label9.TabIndex = 57;
            label9.Text = "Name";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Microsoft Sans Serif", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.White;
            label8.Location = new Point(38, 131);
            label8.Margin = new Padding(2, 0, 2, 0);
            label8.Name = "label8";
            label8.Size = new Size(83, 24);
            label8.TabIndex = 56;
            label8.Text = "E-mail Id";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Microsoft Sans Serif", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.White;
            label7.Location = new Point(38, 182);
            label7.Margin = new Padding(2, 0, 2, 0);
            label7.Name = "label7";
            label7.Size = new Size(135, 24);
            label7.TabIndex = 55;
            label7.Text = "Room Number";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Microsoft Sans Serif", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.White;
            label6.Location = new Point(38, 241);
            label6.Margin = new Padding(2, 0, 2, 0);
            label6.Name = "label6";
            label6.Size = new Size(63, 24);
            label6.TabIndex = 54;
            label6.Text = "Month";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Microsoft Sans Serif", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.White;
            label5.Location = new Point(38, 297);
            label5.Margin = new Padding(2, 0, 2, 0);
            label5.Name = "label5";
            label5.Size = new Size(125, 24);
            label5.TabIndex = 53;
            label5.Text = "Dues Amount";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(38, 27);
            label1.Margin = new Padding(2, 0, 2, 0);
            label1.Name = "label1";
            label1.Size = new Size(141, 24);
            label1.TabIndex = 52;
            label1.Text = "Mobile Number";
            // 
            // btnSearch
            // 
            btnSearch.BorderRadius = 15;
            btnSearch.CustomizableEdges = customizableEdges13;
            btnSearch.DisabledState.BorderColor = Color.DarkGray;
            btnSearch.DisabledState.CustomBorderColor = Color.DarkGray;
            btnSearch.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnSearch.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnSearch.FillColor = Color.Silver;
            btnSearch.Font = new Font("Segoe UI", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnSearch.ForeColor = Color.Black;
            btnSearch.Image = (Image)resources.GetObject("btnSearch.Image");
            btnSearch.ImageSize = new Size(30, 30);
            btnSearch.Location = new Point(573, 26);
            btnSearch.Margin = new Padding(3, 2, 3, 2);
            btnSearch.Name = "btnSearch";
            btnSearch.ShadowDecoration.CustomizableEdges = customizableEdges14;
            btnSearch.Size = new Size(130, 37);
            btnSearch.TabIndex = 79;
            btnSearch.Text = "Search";
            btnSearch.Click += btnSearch_Click;
            // 
            // btnClear
            // 
            btnClear.BorderRadius = 15;
            btnClear.CustomizableEdges = customizableEdges15;
            btnClear.DisabledState.BorderColor = Color.DarkGray;
            btnClear.DisabledState.CustomBorderColor = Color.DarkGray;
            btnClear.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnClear.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnClear.FillColor = Color.Silver;
            btnClear.Font = new Font("Segoe UI", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnClear.ForeColor = Color.Black;
            btnClear.Image = (Image)resources.GetObject("btnClear.Image");
            btnClear.ImageSize = new Size(30, 30);
            btnClear.Location = new Point(744, 347);
            btnClear.Margin = new Padding(3, 2, 3, 2);
            btnClear.Name = "btnClear";
            btnClear.ShadowDecoration.CustomizableEdges = customizableEdges16;
            btnClear.Size = new Size(130, 37);
            btnClear.TabIndex = 80;
            btnClear.Text = "Clear";
            btnClear.Click += btnClear_Click;
            // 
            // btnPay
            // 
            btnPay.BorderRadius = 15;
            btnPay.CustomizableEdges = customizableEdges17;
            btnPay.DisabledState.BorderColor = Color.DarkGray;
            btnPay.DisabledState.CustomBorderColor = Color.DarkGray;
            btnPay.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnPay.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnPay.FillColor = Color.Silver;
            btnPay.Font = new Font("Segoe UI", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnPay.ForeColor = Color.Black;
            btnPay.Image = (Image)resources.GetObject("btnPay.Image");
            btnPay.ImageSize = new Size(30, 30);
            btnPay.Location = new Point(589, 347);
            btnPay.Margin = new Padding(3, 2, 3, 2);
            btnPay.Name = "btnPay";
            btnPay.ShadowDecoration.CustomizableEdges = customizableEdges18;
            btnPay.Size = new Size(130, 37);
            btnPay.TabIndex = 81;
            btnPay.Text = "Pay";
            btnPay.Click += btnPay_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(10, 396);
            dataGridView1.Margin = new Padding(2);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.Size = new Size(987, 181);
            dataGridView1.TabIndex = 82;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // dateTimePicker
            // 
            dateTimePicker.Checked = true;
            dateTimePicker.CustomizableEdges = customizableEdges19;
            dateTimePicker.Font = new Font("Segoe UI", 9F);
            dateTimePicker.Format = DateTimePickerFormat.Long;
            dateTimePicker.Location = new Point(209, 230);
            dateTimePicker.Margin = new Padding(2);
            dateTimePicker.MaxDate = new DateTime(9998, 12, 31, 0, 0, 0, 0);
            dateTimePicker.MinDate = new DateTime(1753, 1, 1, 0, 0, 0, 0);
            dateTimePicker.Name = "dateTimePicker";
            dateTimePicker.ShadowDecoration.CustomizableEdges = customizableEdges20;
            dateTimePicker.Size = new Size(695, 43);
            dateTimePicker.TabIndex = 83;
            dateTimePicker.Value = new DateTime(2024, 10, 5, 16, 26, 8, 487);
            // 
            // StudentFees
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Purple;
            ClientSize = new Size(1006, 590);
            Controls.Add(dateTimePicker);
            Controls.Add(dataGridView1);
            Controls.Add(btnPay);
            Controls.Add(btnClear);
            Controls.Add(btnSearch);
            Controls.Add(txtName);
            Controls.Add(txtEmailId);
            Controls.Add(txtRoomNo);
            Controls.Add(txtAmount);
            Controls.Add(txtMobile);
            Controls.Add(btnExit);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(2);
            Name = "StudentFees";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "StudentFees";
            Load += StudentFees_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Guna.UI2.WinForms.Guna2TextBox txtName;
        private Guna.UI2.WinForms.Guna2TextBox txtEmailId;
        private Guna.UI2.WinForms.Guna2TextBox txtRoomNo;
        private Guna.UI2.WinForms.Guna2TextBox txtAmount;
        private Guna.UI2.WinForms.Guna2TextBox txtMobile;
        private Guna.UI2.WinForms.Guna2Button btnExit;
        private Label label9;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label1;
        private Guna.UI2.WinForms.Guna2Button btnSearch;
        private Guna.UI2.WinForms.Guna2Button btnClear;
        private Guna.UI2.WinForms.Guna2Button btnPay;
        private DataGridView dataGridView1;
        private Guna.UI2.WinForms.Guna2DateTimePicker dateTimePicker;
    }
}