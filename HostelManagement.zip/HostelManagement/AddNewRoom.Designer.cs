﻿namespace HostelManagement
{
    partial class AddNewRoom
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddNewRoom));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            txtRoomNo1 = new Guna.UI2.WinForms.Guna2TextBox();
            CheckBox1 = new Guna.UI2.WinForms.Guna2CheckBox();
            All = new Label();
            dataGridView1 = new Guna.UI2.WinForms.Guna2DataGridView();
            txtRoomNo2 = new Guna.UI2.WinForms.Guna2TextBox();
            guna2Button5 = new Guna.UI2.WinForms.Guna2Button();
            btnUpdate = new Guna.UI2.WinForms.Guna2Button();
            btnDelete = new Guna.UI2.WinForms.Guna2Button();
            guna2Button8 = new Guna.UI2.WinForms.Guna2Button();
            btnExit = new Guna.UI2.WinForms.Guna2Button();
            CheckBox2 = new Guna.UI2.WinForms.Guna2CheckBox();
            lblRoomExist = new Label();
            lebelRoom = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(26, 27);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(269, 40);
            label1.TabIndex = 0;
            label1.Text = "Add New Room";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft Sans Serif", 11F);
            label2.ForeColor = Color.White;
            label2.Location = new Point(35, 99);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(155, 26);
            label2.TabIndex = 1;
            label2.Text = "Room Number";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft Sans Serif", 11F);
            label3.ForeColor = Color.White;
            label3.Location = new Point(496, 96);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(229, 26);
            label3.TabIndex = 2;
            label3.Text = "Activate Or Deactivate";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft Sans Serif", 18F);
            label4.ForeColor = Color.White;
            label4.Location = new Point(26, 177);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(403, 40);
            label4.TabIndex = 3;
            label4.Text = "Update Or Delete Room";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Microsoft Sans Serif", 11F);
            label5.ForeColor = Color.White;
            label5.Location = new Point(672, 260);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(229, 26);
            label5.TabIndex = 4;
            label5.Text = "Activate Or Deactivate";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Microsoft Sans Serif", 11F);
            label6.ForeColor = Color.White;
            label6.Location = new Point(35, 265);
            label6.Margin = new Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new Size(155, 26);
            label6.TabIndex = 5;
            label6.Text = "Room Number";
            // 
            // txtRoomNo1
            // 
            txtRoomNo1.CustomizableEdges = customizableEdges1;
            txtRoomNo1.DefaultText = "";
            txtRoomNo1.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtRoomNo1.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtRoomNo1.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtRoomNo1.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtRoomNo1.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtRoomNo1.Font = new Font("Segoe UI", 9F);
            txtRoomNo1.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtRoomNo1.Location = new Point(213, 96);
            txtRoomNo1.Margin = new Padding(4, 5, 4, 5);
            txtRoomNo1.Name = "txtRoomNo1";
            txtRoomNo1.PasswordChar = '\0';
            txtRoomNo1.PlaceholderText = "";
            txtRoomNo1.SelectedText = "";
            txtRoomNo1.ShadowDecoration.CustomizableEdges = customizableEdges2;
            txtRoomNo1.Size = new Size(238, 38);
            txtRoomNo1.TabIndex = 6;
            // 
            // CheckBox1
            // 
            CheckBox1.AutoSize = true;
            CheckBox1.CheckedState.BorderColor = Color.FromArgb(94, 148, 255);
            CheckBox1.CheckedState.BorderRadius = 0;
            CheckBox1.CheckedState.BorderThickness = 0;
            CheckBox1.CheckedState.FillColor = Color.FromArgb(94, 148, 255);
            CheckBox1.ForeColor = Color.White;
            CheckBox1.Location = new Point(781, 96);
            CheckBox1.Margin = new Padding(4, 3, 4, 3);
            CheckBox1.Name = "CheckBox1";
            CheckBox1.Size = new Size(77, 30);
            CheckBox1.TabIndex = 10;
            CheckBox1.Text = "Yes";
            CheckBox1.UncheckedState.BorderColor = Color.FromArgb(125, 137, 149);
            CheckBox1.UncheckedState.BorderRadius = 0;
            CheckBox1.UncheckedState.BorderThickness = 0;
            CheckBox1.UncheckedState.FillColor = Color.FromArgb(125, 137, 149);
            // 
            // All
            // 
            All.AutoSize = true;
            All.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            All.ForeColor = Color.White;
            All.Location = new Point(496, 417);
            All.Margin = new Padding(4, 0, 4, 0);
            All.Name = "All";
            All.Size = new Size(181, 40);
            All.TabIndex = 14;
            All.Text = "All Rooms";
            // 
            // dataGridView1
            // 
            dataGridViewCellStyle1.BackColor = Color.White;
            dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dataGridView1.BackgroundColor = Color.FromArgb(255, 224, 192);
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.FromArgb(100, 88, 255);
            dataGridViewCellStyle2.Font = new Font("Microsoft Sans Serif", 11F);
            dataGridViewCellStyle2.ForeColor = Color.White;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            dataGridView1.ColumnHeadersHeight = 4;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = Color.White;
            dataGridViewCellStyle3.Font = new Font("Microsoft Sans Serif", 11F);
            dataGridViewCellStyle3.ForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle3.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dataGridViewCellStyle3.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            dataGridView1.DefaultCellStyle = dataGridViewCellStyle3;
            dataGridView1.GridColor = Color.FromArgb(231, 229, 255);
            dataGridView1.Location = new Point(24, 477);
            dataGridView1.Margin = new Padding(4, 3, 4, 3);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.Size = new Size(1166, 249);
            dataGridView1.TabIndex = 15;
            dataGridView1.ThemeStyle.AlternatingRowsStyle.BackColor = Color.White;
            dataGridView1.ThemeStyle.AlternatingRowsStyle.Font = null;
            dataGridView1.ThemeStyle.AlternatingRowsStyle.ForeColor = Color.Empty;
            dataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = Color.Empty;
            dataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = Color.Empty;
            dataGridView1.ThemeStyle.BackColor = Color.FromArgb(255, 224, 192);
            dataGridView1.ThemeStyle.GridColor = Color.FromArgb(231, 229, 255);
            dataGridView1.ThemeStyle.HeaderStyle.BackColor = Color.FromArgb(100, 88, 255);
            dataGridView1.ThemeStyle.HeaderStyle.BorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridView1.ThemeStyle.HeaderStyle.Font = new Font("Microsoft Sans Serif", 11F);
            dataGridView1.ThemeStyle.HeaderStyle.ForeColor = Color.White;
            dataGridView1.ThemeStyle.HeaderStyle.HeaightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridView1.ThemeStyle.HeaderStyle.Height = 4;
            dataGridView1.ThemeStyle.ReadOnly = false;
            dataGridView1.ThemeStyle.RowsStyle.BackColor = Color.White;
            dataGridView1.ThemeStyle.RowsStyle.BorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dataGridView1.ThemeStyle.RowsStyle.Font = new Font("Microsoft Sans Serif", 11F);
            dataGridView1.ThemeStyle.RowsStyle.ForeColor = Color.FromArgb(71, 69, 94);
            dataGridView1.ThemeStyle.RowsStyle.Height = 33;
            dataGridView1.ThemeStyle.RowsStyle.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dataGridView1.ThemeStyle.RowsStyle.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dataGridView1.CellContentClick += guna2DataGridView1_CellContentClick;
            // 
            // txtRoomNo2
            // 
            txtRoomNo2.CustomizableEdges = customizableEdges3;
            txtRoomNo2.DefaultText = "";
            txtRoomNo2.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtRoomNo2.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtRoomNo2.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtRoomNo2.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtRoomNo2.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtRoomNo2.Font = new Font("Segoe UI", 9F);
            txtRoomNo2.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtRoomNo2.Location = new Point(231, 258);
            txtRoomNo2.Margin = new Padding(4, 5, 4, 5);
            txtRoomNo2.Name = "txtRoomNo2";
            txtRoomNo2.PasswordChar = '\0';
            txtRoomNo2.PlaceholderText = "";
            txtRoomNo2.SelectedText = "";
            txtRoomNo2.ShadowDecoration.CustomizableEdges = customizableEdges4;
            txtRoomNo2.Size = new Size(220, 40);
            txtRoomNo2.TabIndex = 17;
            // 
            // guna2Button5
            // 
            guna2Button5.BorderRadius = 15;
            guna2Button5.CustomizableEdges = customizableEdges5;
            guna2Button5.DisabledState.BorderColor = Color.DarkGray;
            guna2Button5.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button5.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button5.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button5.FillColor = Color.Red;
            guna2Button5.Font = new Font("Segoe UI", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            guna2Button5.ForeColor = Color.Black;
            guna2Button5.Image = (Image)resources.GetObject("guna2Button5.Image");
            guna2Button5.ImageSize = new Size(30, 30);
            guna2Button5.Location = new Point(895, 88);
            guna2Button5.Margin = new Padding(4, 3, 4, 3);
            guna2Button5.Name = "guna2Button5";
            guna2Button5.ShadowDecoration.CustomizableEdges = customizableEdges6;
            guna2Button5.Size = new Size(163, 46);
            guna2Button5.TabIndex = 18;
            guna2Button5.Text = "Add Room";
            guna2Button5.Click += guna2Button5_Click;
            // 
            // btnUpdate
            // 
            btnUpdate.BorderRadius = 15;
            btnUpdate.CustomizableEdges = customizableEdges7;
            btnUpdate.DisabledState.BorderColor = Color.DarkGray;
            btnUpdate.DisabledState.CustomBorderColor = Color.DarkGray;
            btnUpdate.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnUpdate.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnUpdate.FillColor = Color.Silver;
            btnUpdate.Font = new Font("Segoe UI", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnUpdate.ForeColor = Color.Black;
            btnUpdate.Image = (Image)resources.GetObject("btnUpdate.Image");
            btnUpdate.ImageSize = new Size(30, 30);
            btnUpdate.Location = new Point(769, 324);
            btnUpdate.Margin = new Padding(4, 3, 4, 3);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.ShadowDecoration.CustomizableEdges = customizableEdges8;
            btnUpdate.Size = new Size(163, 46);
            btnUpdate.TabIndex = 19;
            btnUpdate.Text = "Update";
            btnUpdate.Click += btnUpdate_Click;
            // 
            // btnDelete
            // 
            btnDelete.BorderRadius = 15;
            btnDelete.CustomizableEdges = customizableEdges9;
            btnDelete.DisabledState.BorderColor = Color.DarkGray;
            btnDelete.DisabledState.CustomBorderColor = Color.DarkGray;
            btnDelete.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnDelete.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnDelete.FillColor = Color.Silver;
            btnDelete.Font = new Font("Segoe UI", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnDelete.ForeColor = Color.Black;
            btnDelete.Image = (Image)resources.GetObject("btnDelete.Image");
            btnDelete.ImageSize = new Size(30, 30);
            btnDelete.Location = new Point(952, 324);
            btnDelete.Margin = new Padding(4, 3, 4, 3);
            btnDelete.Name = "btnDelete";
            btnDelete.ShadowDecoration.CustomizableEdges = customizableEdges10;
            btnDelete.Size = new Size(163, 46);
            btnDelete.TabIndex = 20;
            btnDelete.Text = "Delete";
            btnDelete.Click += btnDelete_Click;
            // 
            // guna2Button8
            // 
            guna2Button8.BorderRadius = 15;
            guna2Button8.CustomizableEdges = customizableEdges11;
            guna2Button8.DisabledState.BorderColor = Color.DarkGray;
            guna2Button8.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button8.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button8.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button8.FillColor = Color.FromArgb(255, 128, 128);
            guna2Button8.Font = new Font("Segoe UI", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            guna2Button8.ForeColor = Color.Black;
            guna2Button8.Image = (Image)resources.GetObject("guna2Button8.Image");
            guna2Button8.ImageSize = new Size(30, 30);
            guna2Button8.Location = new Point(476, 252);
            guna2Button8.Margin = new Padding(4, 3, 4, 3);
            guna2Button8.Name = "guna2Button8";
            guna2Button8.ShadowDecoration.CustomizableEdges = customizableEdges12;
            guna2Button8.Size = new Size(163, 46);
            guna2Button8.TabIndex = 21;
            guna2Button8.Text = "Search";
            guna2Button8.Click += guna2Button8_Click;
            // 
            // btnExit
            // 
            btnExit.BorderRadius = 15;
            btnExit.CustomizableEdges = customizableEdges13;
            btnExit.DisabledState.BorderColor = Color.DarkGray;
            btnExit.DisabledState.CustomBorderColor = Color.DarkGray;
            btnExit.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnExit.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnExit.FillColor = Color.Purple;
            btnExit.Font = new Font("Segoe UI", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnExit.ForeColor = Color.White;
            btnExit.Image = (Image)resources.GetObject("btnExit.Image");
            btnExit.ImageSize = new Size(45, 45);
            btnExit.Location = new Point(1166, 5);
            btnExit.Margin = new Padding(4, 3, 4, 3);
            btnExit.Name = "btnExit";
            btnExit.ShadowDecoration.CustomizableEdges = customizableEdges14;
            btnExit.Size = new Size(77, 58);
            btnExit.TabIndex = 22;
            btnExit.Click += guna2Button1_Click;
            // 
            // CheckBox2
            // 
            CheckBox2.AutoSize = true;
            CheckBox2.CheckedState.BorderColor = Color.FromArgb(94, 148, 255);
            CheckBox2.CheckedState.BorderRadius = 0;
            CheckBox2.CheckedState.BorderThickness = 0;
            CheckBox2.CheckedState.FillColor = Color.FromArgb(94, 148, 255);
            CheckBox2.ForeColor = Color.White;
            CheckBox2.Location = new Point(951, 259);
            CheckBox2.Margin = new Padding(4, 3, 4, 3);
            CheckBox2.Name = "CheckBox2";
            CheckBox2.Size = new Size(77, 30);
            CheckBox2.TabIndex = 23;
            CheckBox2.Text = "Yes";
            CheckBox2.UncheckedState.BorderColor = Color.FromArgb(125, 137, 149);
            CheckBox2.UncheckedState.BorderRadius = 0;
            CheckBox2.UncheckedState.BorderThickness = 0;
            CheckBox2.UncheckedState.FillColor = Color.FromArgb(125, 137, 149);
            // 
            // lblRoomExist
            // 
            lblRoomExist.AutoSize = true;
            lblRoomExist.Font = new Font("Microsoft Sans Serif", 11F);
            lblRoomExist.ForeColor = Color.Yellow;
            lblRoomExist.Location = new Point(257, 136);
            lblRoomExist.Margin = new Padding(4, 0, 4, 0);
            lblRoomExist.Name = "lblRoomExist";
            lblRoomExist.Size = new Size(82, 26);
            lblRoomExist.TabIndex = 24;
            lblRoomExist.Text = "setText";
            lblRoomExist.Click += lblRoomExit_Click;
            // 
            // lebelRoom
            // 
            lebelRoom.AutoSize = true;
            lebelRoom.Font = new Font("Microsoft Sans Serif", 11F);
            lebelRoom.ForeColor = Color.Yellow;
            lebelRoom.Location = new Point(257, 298);
            lebelRoom.Margin = new Padding(4, 0, 4, 0);
            lebelRoom.Name = "lebelRoom";
            lebelRoom.Size = new Size(82, 26);
            lebelRoom.TabIndex = 25;
            lebelRoom.Text = "setText";
            lebelRoom.Click += lebelRoomExi_Click;
            // 
            // AddNewRoom
            // 
            AutoScaleDimensions = new SizeF(13F, 26F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Purple;
            ClientSize = new Size(1232, 794);
            Controls.Add(lebelRoom);
            Controls.Add(lblRoomExist);
            Controls.Add(CheckBox2);
            Controls.Add(btnExit);
            Controls.Add(guna2Button8);
            Controls.Add(btnDelete);
            Controls.Add(btnUpdate);
            Controls.Add(guna2Button5);
            Controls.Add(txtRoomNo2);
            Controls.Add(dataGridView1);
            Controls.Add(All);
            Controls.Add(CheckBox1);
            Controls.Add(txtRoomNo1);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Font = new Font("Microsoft Sans Serif", 11F);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(4, 3, 4, 3);
            Name = "AddNewRoom";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "AddNewRoom";
            Load += AddNewRoom_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Guna.UI2.WinForms.Guna2TextBox txtRoomNo1;
        private Guna.UI2.WinForms.Guna2CheckBox CheckBox1;
        private Label All;
        private Guna.UI2.WinForms.Guna2DataGridView dataGridView1;
        private Guna.UI2.WinForms.Guna2TextBox txtRoomNo2;
        private Guna.UI2.WinForms.Guna2Button guna2Button5;
        private Guna.UI2.WinForms.Guna2Button btnUpdate;
        private Guna.UI2.WinForms.Guna2Button btnDelete;
        private Guna.UI2.WinForms.Guna2Button guna2Button8;
        private Guna.UI2.WinForms.Guna2Button btnExit;
        private Guna.UI2.WinForms.Guna2CheckBox CheckBox2;
        private Label lblRoomExist;
        private Label lebelRoom;
    }
}