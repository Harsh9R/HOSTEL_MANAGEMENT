﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HostelManagement
{
    public partial class NewEmployee : Form
    {
        function fn = new function();
        String query;

        public NewEmployee()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        private void NewEmployee_Load(object sender, EventArgs e)
        {
            this.Location = new Point(350, 170);
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
        private void guna2TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void searchBtn_Click(object sender, EventArgs e)
        {
            if (txtMobile.Text != "" && txtName.Text != "" && txtfName.Text != "" && txtmName.Text != ""
                && txtEmail.Text != "" && txtAddr.Text != "" && txtUid.Text != "" && comboBox1.SelectedIndex != -1)
            {
                Int64 mobile = Int64.Parse(txtMobile.Text);
                String name = txtName.Text;
                String fname = txtfName.Text;
                String mname = txtmName.Text;
                String email = txtEmail.Text;
                String address = txtAddr.Text;
                String uid = txtUid.Text;
                String designation = comboBox1.Text;

                query = "insert into newEmployee(emobile,ename,efname,emname,eemail,epaddress,eidproof,edesignation) values(" + mobile + ",'" + name + "','" + fname + "','" + mname + "','" + email + "','" + address + "','" + uid + "','" + designation + "')";
                fn.setData(query, "Employee Registration Succesfull...");
                this.Close();
            }
            else
            {
                MessageBox.Show("Fill all Required Data.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnclr_Click(object sender, EventArgs e)
        {
            clearAll();
        }
        private void clearAll()
        {
            txtMobile.Clear();
            txtName.Clear();
            txtfName.Clear();
            txtmName.Clear();
            txtEmail.Clear();
            txtAddr.Clear();
            txtUid.Clear();
            comboBox1.SelectedIndex = -1;
        }

    }
}
