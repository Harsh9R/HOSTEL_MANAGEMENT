﻿namespace HostelManagement
{
    partial class NewStudent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges23 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NewStudent));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges24 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges25 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges26 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges27 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges28 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges29 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges30 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges31 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges32 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges33 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges34 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges35 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges36 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges37 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges38 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges39 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges40 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges41 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges42 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges43 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges44 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            lblName = new Label();
            lblFName = new Label();
            lblMName = new Label();
            lblEmail = new Label();
            lblAddress = new Label();
            lblCollegeName = new Label();
            lblIdProof = new Label();
            lblMobileNo = new Label();
            comboRoomNo = new ComboBox();
            btnSave = new Guna.UI2.WinForms.Guna2Button();
            btnClear = new Guna.UI2.WinForms.Guna2Button();
            txtName = new Guna.UI2.WinForms.Guna2TextBox();
            txtFather = new Guna.UI2.WinForms.Guna2TextBox();
            txtMother = new Guna.UI2.WinForms.Guna2TextBox();
            txtCollege = new Guna.UI2.WinForms.Guna2TextBox();
            txtPermanent = new Guna.UI2.WinForms.Guna2TextBox();
            txtEmail = new Guna.UI2.WinForms.Guna2TextBox();
            txtMobile = new Guna.UI2.WinForms.Guna2TextBox();
            btnExit = new Guna.UI2.WinForms.Guna2Button();
            lblRoomNo = new Label();
            txtIdProof = new Guna.UI2.WinForms.Guna2TextBox();
            SuspendLayout();
            // 
            // lblName
            // 
            lblName.AutoSize = true;
            lblName.Font = new Font("Microsoft Sans Serif", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblName.ForeColor = Color.White;
            lblName.Location = new Point(48, 86);
            lblName.Margin = new Padding(2, 0, 2, 0);
            lblName.Name = "lblName";
            lblName.Size = new Size(61, 24);
            lblName.TabIndex = 39;
            lblName.Text = "Name";
            // 
            // lblFName
            // 
            lblFName.AutoSize = true;
            lblFName.Font = new Font("Microsoft Sans Serif", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblFName.ForeColor = Color.White;
            lblFName.Location = new Point(49, 139);
            lblFName.Margin = new Padding(2, 0, 2, 0);
            lblFName.Name = "lblFName";
            lblFName.Size = new Size(120, 24);
            lblFName.TabIndex = 38;
            lblFName.Text = "Father Name";
            // 
            // lblMName
            // 
            lblMName.AutoSize = true;
            lblMName.Font = new Font("Microsoft Sans Serif", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblMName.ForeColor = Color.White;
            lblMName.Location = new Point(49, 190);
            lblMName.Margin = new Padding(2, 0, 2, 0);
            lblMName.Name = "lblMName";
            lblMName.Size = new Size(125, 24);
            lblMName.TabIndex = 37;
            lblMName.Text = "Mother Name";
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.Font = new Font("Microsoft Sans Serif", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblEmail.ForeColor = Color.White;
            lblEmail.Location = new Point(49, 249);
            lblEmail.Margin = new Padding(2, 0, 2, 0);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(83, 24);
            lblEmail.TabIndex = 36;
            lblEmail.Text = "E-mail Id";
            // 
            // lblAddress
            // 
            lblAddress.AutoSize = true;
            lblAddress.Font = new Font("Microsoft Sans Serif", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblAddress.ForeColor = Color.White;
            lblAddress.Location = new Point(49, 305);
            lblAddress.Margin = new Padding(2, 0, 2, 0);
            lblAddress.Name = "lblAddress";
            lblAddress.Size = new Size(80, 24);
            lblAddress.TabIndex = 35;
            lblAddress.Text = "Address";
            // 
            // lblCollegeName
            // 
            lblCollegeName.AutoSize = true;
            lblCollegeName.Font = new Font("Microsoft Sans Serif", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblCollegeName.ForeColor = Color.White;
            lblCollegeName.Location = new Point(49, 363);
            lblCollegeName.Margin = new Padding(2, 0, 2, 0);
            lblCollegeName.Name = "lblCollegeName";
            lblCollegeName.Size = new Size(131, 24);
            lblCollegeName.TabIndex = 34;
            lblCollegeName.Text = "College Name";
            // 
            // lblIdProof
            // 
            lblIdProof.AutoSize = true;
            lblIdProof.Font = new Font("Microsoft Sans Serif", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblIdProof.ForeColor = Color.White;
            lblIdProof.Location = new Point(49, 414);
            lblIdProof.Margin = new Padding(2, 0, 2, 0);
            lblIdProof.Name = "lblIdProof";
            lblIdProof.Size = new Size(74, 24);
            lblIdProof.TabIndex = 33;
            lblIdProof.Text = "Id Proof";
            // 
            // lblMobileNo
            // 
            lblMobileNo.AutoSize = true;
            lblMobileNo.Font = new Font("Microsoft Sans Serif", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblMobileNo.ForeColor = Color.White;
            lblMobileNo.Location = new Point(49, 35);
            lblMobileNo.Margin = new Padding(2, 0, 2, 0);
            lblMobileNo.Name = "lblMobileNo";
            lblMobileNo.Size = new Size(141, 24);
            lblMobileNo.TabIndex = 32;
            lblMobileNo.Text = "Mobile Number";
            // 
            // comboRoomNo
            // 
            comboRoomNo.FormattingEnabled = true;
            comboRoomNo.Location = new Point(220, 457);
            comboRoomNo.Margin = new Padding(2);
            comboRoomNo.Name = "comboRoomNo";
            comboRoomNo.Size = new Size(696, 28);
            comboRoomNo.TabIndex = 54;
            // 
            // btnSave
            // 
            btnSave.BorderRadius = 15;
            btnSave.CustomizableEdges = customizableEdges23;
            btnSave.DisabledState.BorderColor = Color.DarkGray;
            btnSave.DisabledState.CustomBorderColor = Color.DarkGray;
            btnSave.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnSave.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnSave.FillColor = Color.Silver;
            btnSave.Font = new Font("Segoe UI", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnSave.ForeColor = Color.Black;
            btnSave.Image = (Image)resources.GetObject("btnSave.Image");
            btnSave.ImageSize = new Size(30, 30);
            btnSave.Location = new Point(622, 495);
            btnSave.Margin = new Padding(3, 2, 3, 2);
            btnSave.Name = "btnSave";
            btnSave.ShadowDecoration.CustomizableEdges = customizableEdges24;
            btnSave.Size = new Size(130, 37);
            btnSave.TabIndex = 53;
            btnSave.Text = "Save";
            btnSave.Click += guna2Button1_Click;
            // 
            // btnClear
            // 
            btnClear.BorderRadius = 15;
            btnClear.CustomizableEdges = customizableEdges25;
            btnClear.DisabledState.BorderColor = Color.DarkGray;
            btnClear.DisabledState.CustomBorderColor = Color.DarkGray;
            btnClear.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnClear.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnClear.FillColor = Color.Silver;
            btnClear.Font = new Font("Segoe UI", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnClear.ForeColor = Color.Black;
            btnClear.Image = (Image)resources.GetObject("btnClear.Image");
            btnClear.ImageSize = new Size(30, 30);
            btnClear.Location = new Point(785, 495);
            btnClear.Margin = new Padding(3, 2, 3, 2);
            btnClear.Name = "btnClear";
            btnClear.ShadowDecoration.CustomizableEdges = customizableEdges26;
            btnClear.Size = new Size(130, 37);
            btnClear.TabIndex = 52;
            btnClear.Text = "Clear";
            btnClear.Click += guna2Button8_Click;
            // 
            // txtName
            // 
            txtName.CustomizableEdges = customizableEdges27;
            txtName.DefaultText = "";
            txtName.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtName.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtName.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtName.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtName.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtName.Font = new Font("Segoe UI", 9F);
            txtName.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtName.Location = new Point(220, 85);
            txtName.Margin = new Padding(3, 4, 3, 4);
            txtName.Name = "txtName";
            txtName.PasswordChar = '\0';
            txtName.PlaceholderText = "";
            txtName.SelectedText = "";
            txtName.ShadowDecoration.CustomizableEdges = customizableEdges28;
            txtName.Size = new Size(695, 34);
            txtName.TabIndex = 51;
            // 
            // txtFather
            // 
            txtFather.CustomizableEdges = customizableEdges29;
            txtFather.DefaultText = "";
            txtFather.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtFather.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtFather.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtFather.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtFather.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtFather.Font = new Font("Segoe UI", 9F);
            txtFather.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtFather.Location = new Point(220, 134);
            txtFather.Margin = new Padding(3, 4, 3, 4);
            txtFather.Name = "txtFather";
            txtFather.PasswordChar = '\0';
            txtFather.PlaceholderText = "";
            txtFather.SelectedText = "";
            txtFather.ShadowDecoration.CustomizableEdges = customizableEdges30;
            txtFather.Size = new Size(695, 34);
            txtFather.TabIndex = 50;
            // 
            // txtMother
            // 
            txtMother.CustomizableEdges = customizableEdges31;
            txtMother.DefaultText = "";
            txtMother.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtMother.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtMother.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtMother.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtMother.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtMother.Font = new Font("Segoe UI", 9F);
            txtMother.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtMother.Location = new Point(220, 189);
            txtMother.Margin = new Padding(3, 4, 3, 4);
            txtMother.Name = "txtMother";
            txtMother.PasswordChar = '\0';
            txtMother.PlaceholderText = "";
            txtMother.SelectedText = "";
            txtMother.ShadowDecoration.CustomizableEdges = customizableEdges32;
            txtMother.Size = new Size(695, 34);
            txtMother.TabIndex = 49;
            // 
            // txtCollege
            // 
            txtCollege.CustomizableEdges = customizableEdges33;
            txtCollege.DefaultText = "";
            txtCollege.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtCollege.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtCollege.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtCollege.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtCollege.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtCollege.Font = new Font("Segoe UI", 9F);
            txtCollege.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtCollege.Location = new Point(220, 357);
            txtCollege.Margin = new Padding(3, 4, 3, 4);
            txtCollege.Name = "txtCollege";
            txtCollege.PasswordChar = '\0';
            txtCollege.PlaceholderText = "";
            txtCollege.SelectedText = "";
            txtCollege.ShadowDecoration.CustomizableEdges = customizableEdges34;
            txtCollege.Size = new Size(695, 34);
            txtCollege.TabIndex = 48;
            // 
            // txtPermanent
            // 
            txtPermanent.CustomizableEdges = customizableEdges35;
            txtPermanent.DefaultText = "";
            txtPermanent.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtPermanent.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtPermanent.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtPermanent.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtPermanent.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPermanent.Font = new Font("Segoe UI", 9F);
            txtPermanent.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPermanent.Location = new Point(220, 300);
            txtPermanent.Margin = new Padding(3, 4, 3, 4);
            txtPermanent.Name = "txtPermanent";
            txtPermanent.PasswordChar = '\0';
            txtPermanent.PlaceholderText = "";
            txtPermanent.SelectedText = "";
            txtPermanent.ShadowDecoration.CustomizableEdges = customizableEdges36;
            txtPermanent.Size = new Size(695, 34);
            txtPermanent.TabIndex = 47;
            // 
            // txtEmail
            // 
            txtEmail.CustomizableEdges = customizableEdges37;
            txtEmail.DefaultText = "";
            txtEmail.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtEmail.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtEmail.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtEmail.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtEmail.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtEmail.Font = new Font("Segoe UI", 9F);
            txtEmail.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtEmail.Location = new Point(220, 242);
            txtEmail.Margin = new Padding(3, 4, 3, 4);
            txtEmail.Name = "txtEmail";
            txtEmail.PasswordChar = '\0';
            txtEmail.PlaceholderText = "";
            txtEmail.SelectedText = "";
            txtEmail.ShadowDecoration.CustomizableEdges = customizableEdges38;
            txtEmail.Size = new Size(695, 34);
            txtEmail.TabIndex = 46;
            // 
            // txtMobile
            // 
            txtMobile.CustomizableEdges = customizableEdges39;
            txtMobile.DefaultText = "";
            txtMobile.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtMobile.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtMobile.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtMobile.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtMobile.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtMobile.Font = new Font("Segoe UI", 9F);
            txtMobile.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtMobile.Location = new Point(220, 35);
            txtMobile.Margin = new Padding(3, 4, 3, 4);
            txtMobile.Name = "txtMobile";
            txtMobile.PasswordChar = '\0';
            txtMobile.PlaceholderText = "";
            txtMobile.SelectedText = "";
            txtMobile.ShadowDecoration.CustomizableEdges = customizableEdges40;
            txtMobile.Size = new Size(695, 34);
            txtMobile.TabIndex = 45;
            // 
            // btnExit
            // 
            btnExit.BorderRadius = 15;
            btnExit.CustomizableEdges = customizableEdges41;
            btnExit.DisabledState.BorderColor = Color.DarkGray;
            btnExit.DisabledState.CustomBorderColor = Color.DarkGray;
            btnExit.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnExit.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnExit.FillColor = Color.Purple;
            btnExit.Font = new Font("Segoe UI", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnExit.ForeColor = Color.White;
            btnExit.Image = (Image)resources.GetObject("btnExit.Image");
            btnExit.ImageSize = new Size(45, 45);
            btnExit.Location = new Point(950, 2);
            btnExit.Margin = new Padding(3, 2, 3, 2);
            btnExit.Name = "btnExit";
            btnExit.RightToLeft = RightToLeft.No;
            btnExit.ShadowDecoration.CustomizableEdges = customizableEdges42;
            btnExit.Size = new Size(62, 58);
            btnExit.TabIndex = 44;
            btnExit.Click += btnExit_Click;
            // 
            // lblRoomNo
            // 
            lblRoomNo.AutoSize = true;
            lblRoomNo.Font = new Font("Microsoft Sans Serif", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblRoomNo.ForeColor = Color.White;
            lblRoomNo.Location = new Point(49, 461);
            lblRoomNo.Margin = new Padding(2, 0, 2, 0);
            lblRoomNo.Name = "lblRoomNo";
            lblRoomNo.Size = new Size(135, 24);
            lblRoomNo.TabIndex = 55;
            lblRoomNo.Text = "Room Number";
            // 
            // txtIdProof
            // 
            txtIdProof.CustomizableEdges = customizableEdges43;
            txtIdProof.DefaultText = "";
            txtIdProof.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtIdProof.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtIdProof.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtIdProof.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtIdProof.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtIdProof.Font = new Font("Segoe UI", 9F);
            txtIdProof.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtIdProof.Location = new Point(220, 407);
            txtIdProof.Margin = new Padding(3, 4, 3, 4);
            txtIdProof.Name = "txtIdProof";
            txtIdProof.PasswordChar = '\0';
            txtIdProof.PlaceholderText = "";
            txtIdProof.SelectedText = "";
            txtIdProof.ShadowDecoration.CustomizableEdges = customizableEdges44;
            txtIdProof.Size = new Size(695, 34);
            txtIdProof.TabIndex = 56;
            // 
            // NewStudent
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Purple;
            ClientSize = new Size(1016, 555);
            Controls.Add(txtIdProof);
            Controls.Add(lblRoomNo);
            Controls.Add(comboRoomNo);
            Controls.Add(btnSave);
            Controls.Add(btnClear);
            Controls.Add(txtName);
            Controls.Add(txtFather);
            Controls.Add(txtMother);
            Controls.Add(txtCollege);
            Controls.Add(txtPermanent);
            Controls.Add(txtEmail);
            Controls.Add(txtMobile);
            Controls.Add(btnExit);
            Controls.Add(lblName);
            Controls.Add(lblFName);
            Controls.Add(lblMName);
            Controls.Add(lblEmail);
            Controls.Add(lblAddress);
            Controls.Add(lblCollegeName);
            Controls.Add(lblIdProof);
            Controls.Add(lblMobileNo);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(2);
            Name = "NewStudent";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "NewStudent";
            Load += NewStudent_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblName;
        private Label lblFName;
        private Label lblMName;
        private Label lblEmail;
        private Label lblAddress;
        private Label lblCollegeName;
        private Label lblIdProof;
        private Label lblMobileNo;
        private ComboBox comboRoomNo;
        private Guna.UI2.WinForms.Guna2Button btnSave;
        private Guna.UI2.WinForms.Guna2Button btnClear;
        private Guna.UI2.WinForms.Guna2TextBox txtName;
        private Guna.UI2.WinForms.Guna2TextBox txtFather;
        private Guna.UI2.WinForms.Guna2TextBox txtMother;
        private Guna.UI2.WinForms.Guna2TextBox txtCollege;
        private Guna.UI2.WinForms.Guna2TextBox txtPermanent;
        private Guna.UI2.WinForms.Guna2TextBox txtEmail;
        private Guna.UI2.WinForms.Guna2TextBox txtMobile;
        private Guna.UI2.WinForms.Guna2Button btnExit;
        private Label lblRoomNo;
        private Guna.UI2.WinForms.Guna2TextBox txtIdProof;
    }
}