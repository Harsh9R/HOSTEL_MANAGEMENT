﻿namespace HostelManagement
{
    partial class UpdateDeleteEmployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UpdateDeleteEmployee));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges21 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges22 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges23 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges24 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            hmsLabel = new Label();
            btnSearch = new Guna.UI2.WinForms.Guna2Button();
            txtworking = new ComboBox();
            txtName = new Guna.UI2.WinForms.Guna2TextBox();
            txtFname = new Guna.UI2.WinForms.Guna2TextBox();
            txtMname = new Guna.UI2.WinForms.Guna2TextBox();
            txtAddr = new Guna.UI2.WinForms.Guna2TextBox();
            txtEmail = new Guna.UI2.WinForms.Guna2TextBox();
            txtMobno = new Guna.UI2.WinForms.Guna2TextBox();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label1 = new Label();
            label2 = new Label();
            btndelete = new Guna.UI2.WinForms.Guna2Button();
            btnUpdate = new Guna.UI2.WinForms.Guna2Button();
            txtClr = new Guna.UI2.WinForms.Guna2Button();
            btnExit = new Guna.UI2.WinForms.Guna2Button();
            txtDesignation = new ComboBox();
            txtUid = new Guna.UI2.WinForms.Guna2TextBox();
            label3 = new Label();
            SuspendLayout();
            // 
            // hmsLabel
            // 
            hmsLabel.AutoSize = true;
            hmsLabel.Font = new Font("Agency FB", 34F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            hmsLabel.ForeColor = Color.White;
            hmsLabel.Location = new Point(273, 3);
            hmsLabel.Name = "hmsLabel";
            hmsLabel.Size = new Size(702, 81);
            hmsLabel.TabIndex = 3;
            hmsLabel.Text = "Hostel Management System";
            // 
            // btnSearch
            // 
            btnSearch.BorderRadius = 15;
            btnSearch.CustomizableEdges = customizableEdges1;
            btnSearch.DisabledState.BorderColor = Color.DarkGray;
            btnSearch.DisabledState.CustomBorderColor = Color.DarkGray;
            btnSearch.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnSearch.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnSearch.FillColor = Color.Silver;
            btnSearch.Font = new Font("Segoe UI", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnSearch.ForeColor = Color.Black;
            btnSearch.Image = (Image)resources.GetObject("btnSearch.Image");
            btnSearch.ImageSize = new Size(30, 30);
            btnSearch.Location = new Point(749, 142);
            btnSearch.Margin = new Padding(4, 3, 4, 3);
            btnSearch.Name = "btnSearch";
            btnSearch.ShadowDecoration.CustomizableEdges = customizableEdges2;
            btnSearch.Size = new Size(163, 46);
            btnSearch.TabIndex = 99;
            btnSearch.Text = "Search";
            btnSearch.Click += btnSearch_Click;
            // 
            // txtworking
            // 
            txtworking.FormattingEnabled = true;
            txtworking.Items.AddRange(new object[] { "Yes", "No" });
            txtworking.Location = new Point(306, 657);
            txtworking.Name = "txtworking";
            txtworking.Size = new Size(259, 33);
            txtworking.TabIndex = 96;
            // 
            // txtName
            // 
            txtName.CustomizableEdges = customizableEdges3;
            txtName.DefaultText = "";
            txtName.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtName.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtName.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtName.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtName.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtName.Font = new Font("Segoe UI", 9F);
            txtName.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtName.Location = new Point(306, 209);
            txtName.Margin = new Padding(4, 5, 4, 5);
            txtName.Name = "txtName";
            txtName.PasswordChar = '\0';
            txtName.PlaceholderText = "";
            txtName.SelectedText = "";
            txtName.ShadowDecoration.CustomizableEdges = customizableEdges4;
            txtName.Size = new Size(869, 43);
            txtName.TabIndex = 95;
            // 
            // txtFname
            // 
            txtFname.CustomizableEdges = customizableEdges5;
            txtFname.DefaultText = "";
            txtFname.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtFname.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtFname.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtFname.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtFname.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtFname.Font = new Font("Segoe UI", 9F);
            txtFname.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtFname.Location = new Point(306, 275);
            txtFname.Margin = new Padding(4, 5, 4, 5);
            txtFname.Name = "txtFname";
            txtFname.PasswordChar = '\0';
            txtFname.PlaceholderText = "";
            txtFname.SelectedText = "";
            txtFname.ShadowDecoration.CustomizableEdges = customizableEdges6;
            txtFname.Size = new Size(869, 43);
            txtFname.TabIndex = 94;
            // 
            // txtMname
            // 
            txtMname.CustomizableEdges = customizableEdges7;
            txtMname.DefaultText = "";
            txtMname.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtMname.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtMname.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtMname.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtMname.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtMname.Font = new Font("Segoe UI", 9F);
            txtMname.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtMname.Location = new Point(306, 339);
            txtMname.Margin = new Padding(4, 5, 4, 5);
            txtMname.Name = "txtMname";
            txtMname.PasswordChar = '\0';
            txtMname.PlaceholderText = "";
            txtMname.SelectedText = "";
            txtMname.ShadowDecoration.CustomizableEdges = customizableEdges8;
            txtMname.Size = new Size(869, 43);
            txtMname.TabIndex = 93;
            // 
            // txtAddr
            // 
            txtAddr.CustomizableEdges = customizableEdges9;
            txtAddr.DefaultText = "";
            txtAddr.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtAddr.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtAddr.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtAddr.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtAddr.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtAddr.Font = new Font("Segoe UI", 9F);
            txtAddr.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtAddr.Location = new Point(306, 469);
            txtAddr.Margin = new Padding(4, 5, 4, 5);
            txtAddr.Name = "txtAddr";
            txtAddr.PasswordChar = '\0';
            txtAddr.PlaceholderText = "";
            txtAddr.SelectedText = "";
            txtAddr.ShadowDecoration.CustomizableEdges = customizableEdges10;
            txtAddr.Size = new Size(869, 43);
            txtAddr.TabIndex = 91;
            // 
            // txtEmail
            // 
            txtEmail.CustomizableEdges = customizableEdges11;
            txtEmail.DefaultText = "";
            txtEmail.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtEmail.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtEmail.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtEmail.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtEmail.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtEmail.Font = new Font("Segoe UI", 9F);
            txtEmail.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtEmail.Location = new Point(306, 403);
            txtEmail.Margin = new Padding(4, 5, 4, 5);
            txtEmail.Name = "txtEmail";
            txtEmail.PasswordChar = '\0';
            txtEmail.PlaceholderText = "";
            txtEmail.SelectedText = "";
            txtEmail.ShadowDecoration.CustomizableEdges = customizableEdges12;
            txtEmail.Size = new Size(869, 43);
            txtEmail.TabIndex = 90;
            // 
            // txtMobno
            // 
            txtMobno.CustomizableEdges = customizableEdges13;
            txtMobno.DefaultText = "";
            txtMobno.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtMobno.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtMobno.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtMobno.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtMobno.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtMobno.Font = new Font("Segoe UI", 9F);
            txtMobno.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtMobno.Location = new Point(306, 145);
            txtMobno.Margin = new Padding(4, 5, 4, 5);
            txtMobno.Name = "txtMobno";
            txtMobno.PasswordChar = '\0';
            txtMobno.PlaceholderText = "";
            txtMobno.SelectedText = "";
            txtMobno.ShadowDecoration.CustomizableEdges = customizableEdges14;
            txtMobno.Size = new Size(417, 43);
            txtMobno.TabIndex = 89;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Century Gothic", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.White;
            label9.Location = new Point(91, 209);
            label9.Name = "label9";
            label9.Size = new Size(79, 25);
            label9.TabIndex = 88;
            label9.Text = "Name";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Century Gothic", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.White;
            label8.Location = new Point(92, 275);
            label8.Name = "label8";
            label8.Size = new Size(153, 25);
            label8.TabIndex = 87;
            label8.Text = "Father Name";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Century Gothic", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.White;
            label7.Location = new Point(92, 339);
            label7.Name = "label7";
            label7.Size = new Size(164, 25);
            label7.TabIndex = 86;
            label7.Text = "Mother Name";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Century Gothic", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.White;
            label6.Location = new Point(92, 403);
            label6.Name = "label6";
            label6.Size = new Size(105, 25);
            label6.TabIndex = 85;
            label6.Text = "E-mail Id";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Century Gothic", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.White;
            label5.Location = new Point(92, 469);
            label5.Name = "label5";
            label5.Size = new Size(98, 25);
            label5.TabIndex = 84;
            label5.Text = "Address";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Century Gothic", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.White;
            label4.Location = new Point(91, 591);
            label4.Name = "label4";
            label4.Size = new Size(137, 25);
            label4.TabIndex = 83;
            label4.Text = "Designation";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(92, 145);
            label1.Name = "label1";
            label1.Size = new Size(181, 25);
            label1.TabIndex = 81;
            label1.Text = "Mobile Number";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Century Gothic", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.White;
            label2.Location = new Point(92, 661);
            label2.Name = "label2";
            label2.Size = new Size(169, 25);
            label2.TabIndex = 100;
            label2.Text = "Working Status";
            // 
            // btndelete
            // 
            btndelete.BorderRadius = 15;
            btndelete.CustomizableEdges = customizableEdges15;
            btndelete.DisabledState.BorderColor = Color.DarkGray;
            btndelete.DisabledState.CustomBorderColor = Color.DarkGray;
            btndelete.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btndelete.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btndelete.FillColor = Color.Silver;
            btndelete.Font = new Font("Segoe UI", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btndelete.ForeColor = Color.Black;
            btndelete.Image = (Image)resources.GetObject("btndelete.Image");
            btndelete.ImageSize = new Size(30, 30);
            btndelete.Location = new Point(803, 651);
            btndelete.Margin = new Padding(4, 3, 4, 3);
            btndelete.Name = "btndelete";
            btndelete.ShadowDecoration.CustomizableEdges = customizableEdges16;
            btndelete.Size = new Size(163, 46);
            btndelete.TabIndex = 103;
            btndelete.Text = "Delete";
            btndelete.Click += btndelete_Click;
            // 
            // btnUpdate
            // 
            btnUpdate.BorderRadius = 15;
            btnUpdate.CustomizableEdges = customizableEdges17;
            btnUpdate.DisabledState.BorderColor = Color.DarkGray;
            btnUpdate.DisabledState.CustomBorderColor = Color.DarkGray;
            btnUpdate.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnUpdate.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnUpdate.FillColor = Color.Silver;
            btnUpdate.Font = new Font("Segoe UI", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnUpdate.ForeColor = Color.Black;
            btnUpdate.Image = (Image)resources.GetObject("btnUpdate.Image");
            btnUpdate.ImageSize = new Size(30, 30);
            btnUpdate.Location = new Point(609, 651);
            btnUpdate.Margin = new Padding(4, 3, 4, 3);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.ShadowDecoration.CustomizableEdges = customizableEdges18;
            btnUpdate.Size = new Size(163, 46);
            btnUpdate.TabIndex = 102;
            btnUpdate.Text = "Update";
            btnUpdate.Click += btnUpdate_Click;
            // 
            // txtClr
            // 
            txtClr.BorderRadius = 15;
            txtClr.CustomizableEdges = customizableEdges19;
            txtClr.DisabledState.BorderColor = Color.DarkGray;
            txtClr.DisabledState.CustomBorderColor = Color.DarkGray;
            txtClr.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            txtClr.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            txtClr.FillColor = Color.Silver;
            txtClr.Font = new Font("Segoe UI", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            txtClr.ForeColor = Color.Black;
            txtClr.Image = (Image)resources.GetObject("txtClr.Image");
            txtClr.ImageSize = new Size(30, 30);
            txtClr.Location = new Point(997, 651);
            txtClr.Margin = new Padding(4, 3, 4, 3);
            txtClr.Name = "txtClr";
            txtClr.ShadowDecoration.CustomizableEdges = customizableEdges20;
            txtClr.Size = new Size(163, 46);
            txtClr.TabIndex = 101;
            txtClr.Text = "Clear";
            txtClr.Click += txtClr_Click;
            // 
            // btnExit
            // 
            btnExit.BorderRadius = 15;
            btnExit.CustomizableEdges = customizableEdges21;
            btnExit.DisabledState.BorderColor = Color.DarkGray;
            btnExit.DisabledState.CustomBorderColor = Color.DarkGray;
            btnExit.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnExit.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnExit.FillColor = Color.Purple;
            btnExit.Font = new Font("Segoe UI", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnExit.ForeColor = Color.White;
            btnExit.Image = (Image)resources.GetObject("btnExit.Image");
            btnExit.ImageSize = new Size(45, 45);
            btnExit.Location = new Point(1171, 1);
            btnExit.Margin = new Padding(4, 3, 4, 3);
            btnExit.Name = "btnExit";
            btnExit.RightToLeft = RightToLeft.No;
            btnExit.ShadowDecoration.CustomizableEdges = customizableEdges22;
            btnExit.Size = new Size(77, 72);
            btnExit.TabIndex = 104;
            btnExit.Click += btnExit_Click;
            // 
            // txtDesignation
            // 
            txtDesignation.FormattingEnabled = true;
            txtDesignation.Items.AddRange(new object[] { "Hostel Incharge", "Mess Staff", "Cleaning Staff", "Accounts Manager", "Event Organizer" });
            txtDesignation.Location = new Point(306, 591);
            txtDesignation.Name = "txtDesignation";
            txtDesignation.Size = new Size(869, 33);
            txtDesignation.TabIndex = 105;
            txtDesignation.SelectedIndexChanged += comboBox2_SelectedIndexChanged;
            // 
            // txtUid
            // 
            txtUid.CustomizableEdges = customizableEdges23;
            txtUid.DefaultText = "";
            txtUid.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtUid.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtUid.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtUid.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtUid.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtUid.Font = new Font("Segoe UI", 9F);
            txtUid.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtUid.Location = new Point(306, 530);
            txtUid.Margin = new Padding(4, 5, 4, 5);
            txtUid.Name = "txtUid";
            txtUid.PasswordChar = '\0';
            txtUid.PlaceholderText = "";
            txtUid.SelectedText = "";
            txtUid.ShadowDecoration.CustomizableEdges = customizableEdges24;
            txtUid.Size = new Size(869, 43);
            txtUid.TabIndex = 107;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Century Gothic", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.White;
            label3.Location = new Point(92, 530);
            label3.Name = "label3";
            label3.Size = new Size(114, 25);
            label3.TabIndex = 106;
            label3.Text = "Unique ID";
            label3.Click += label3_Click;
            // 
            // UpdateDeleteEmployee
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Purple;
            ClientSize = new Size(1248, 727);
            Controls.Add(txtUid);
            Controls.Add(label3);
            Controls.Add(txtDesignation);
            Controls.Add(btnExit);
            Controls.Add(btndelete);
            Controls.Add(btnUpdate);
            Controls.Add(txtClr);
            Controls.Add(label2);
            Controls.Add(btnSearch);
            Controls.Add(txtworking);
            Controls.Add(txtName);
            Controls.Add(txtFname);
            Controls.Add(txtMname);
            Controls.Add(txtAddr);
            Controls.Add(txtEmail);
            Controls.Add(txtMobno);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label1);
            Controls.Add(hmsLabel);
            FormBorderStyle = FormBorderStyle.None;
            Name = "UpdateDeleteEmployee";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "UpdateDeleteEmployee";
            Load += UpdateDeleteEmployee_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label hmsLabel;
        private Guna.UI2.WinForms.Guna2Button btnSearch;
        private ComboBox txtworking;
        private Guna.UI2.WinForms.Guna2TextBox txtName;
        private Guna.UI2.WinForms.Guna2TextBox txtFname;
        private Guna.UI2.WinForms.Guna2TextBox txtMname;
        private Guna.UI2.WinForms.Guna2TextBox txtAddr;
        private Guna.UI2.WinForms.Guna2TextBox txtEmail;
        private Guna.UI2.WinForms.Guna2TextBox txtMobno;
        private Label label9;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label1;
        private Label label2;
        private Guna.UI2.WinForms.Guna2Button btndelete;
        private Guna.UI2.WinForms.Guna2Button btnUpdate;
        private Guna.UI2.WinForms.Guna2Button txtClr;
        private Guna.UI2.WinForms.Guna2Button btnExit;
        private ComboBox txtDesignation;
        private Guna.UI2.WinForms.Guna2TextBox txtUid;
        private Label label3;
    }
}