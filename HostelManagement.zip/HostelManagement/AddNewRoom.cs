﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HostelManagement
{
    public partial class AddNewRoom : Form
    {
        function fn = new function();
        String query;

        public AddNewRoom()
        {
            InitializeComponent();
        }

        private void guna2CheckBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void AddNewRoom_Load(object sender, EventArgs e)
        {
            this.Location = new Point(350, 170);
            lebelRoom.Visible = false;
            lblRoomExist.Visible = false;

            query = "select * from rooms";
            DataSet ds = fn.getData(query);

            dataGridView1.DataSource = ds.Tables[0];
        }



        private void guna2DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void lblRoomExit_Click(object sender, EventArgs e)
        {

        }

        private void lebelRoomExi_Click(object sender, EventArgs e)
        {

        }

        private void guna2Button5_Click(object sender, EventArgs e)
        {
            query = "select * from rooms where roomNo=" + txtRoomNo1.Text + "";
            DataSet ds = fn.getData(query);

            if (ds.Tables[0].Rows.Count == 0)
            {
                String status;
                if (CheckBox1.Checked)
                {
                    status = "Yes";
                }
                else
                {
                    status = "No";
                }
                lblRoomExist.Visible = false;
                query = "insert into rooms(roomNo,roomStatus) values(" + txtRoomNo1.Text + ",'" + status + "')";
                fn.setData(query, "Room Added.");
                AddNewRoom_Load(this, null);
            }
            else
            {
                lblRoomExist.Text = "Room All Ready Exist. ";
                lblRoomExist.Visible = true;
            }
        }

        private void guna2Button8_Click(object sender, EventArgs e)
        {
            query = query = "select * from rooms where roomNo=" + txtRoomNo2.Text + "";
            DataSet ds = fn.getData(query);

            if (ds.Tables[0].Rows.Count == 0)
            {
                lebelRoom.Text = "No Room Exist.";
                lebelRoom.Visible = true;
                CheckBox2.Checked = false;

            }
            else
            {
                lebelRoom.Text = "Room Found.";
                lebelRoom.Visible = true;
                if (ds.Tables[0].Rows[0][1].ToString() == "Yes")
                {
                    CheckBox2.Checked = true;

                }
                else
                {
                    CheckBox2.Checked = false;
                }
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            String status;
            if (CheckBox2.Checked)
            {
                status = "Yes";
            }
            else
            {
                status = "No";
            }
            query = "update rooms set roomStatus='" + status + "'where roomNo=" + txtRoomNo2.Text + "";
            fn.setData(query, "Details Updated.");
            AddNewRoom_Load(this, null);

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if(lebelRoom.Text=="Room Found.")
            {
                query = "delete from rooms where roomNo=" + txtRoomNo2.Text + "";
                fn.setData(query, "Room Details Deleated.");
                AddNewRoom_Load(this, null);
            }
            else
            {
                MessageBox.Show("Trying to delete which doesn't Exist ","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }
    }
}
